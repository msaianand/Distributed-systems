package edu.buffalo.cse.cse486586.groupmessenger1;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * GroupMessengerActivity is the main Activity for the assignment.
 * 
 * @author stevko
 *
 */
public class GroupMessengerActivity extends Activity {
    //Added By SAI

    static final String TAG = GroupMessengerActivity.class.getSimpleName();
    //static final String REMOTE_PORT0 = "11108";
    //static final String REMOTE_PORT1 = "11112";
  // static final String REMOTE_PORT[]= {"11108","11112"};//{"11108","11112","11116","11120","11124"};
    static final String REMOTE_PORT[]= {"11108","11112","11116","11120","11124"};

    static final int SERVER_PORT = 10000;
    static final String URL = "content://edu.buffalo.cse.cse486586.groupmessenger1.provider";
    static final Uri CONTENT_URI = Uri.parse(URL);
    static int SEQ_NO = -1;

    private static final String KEY_FIELD = "key";
    private static final String VALUE_FIELD = "value";
    //End Of SAI
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_messenger);




        /*
         * TODO: Use the TextView to display your messages. Though there is no grading component
         * on how you display the messages, if you implement it, it'll make your debugging easier.
         */
        TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());
        
        /*
         * Registers OnPTestClickListener for "button1" in the layout, which is the "PTest" button.
         * OnPTestClickListener demonstrates how to access a ContentProvider.
         */
        findViewById(R.id.button1).setOnClickListener(
                new OnPTestClickListener(tv, getContentResolver()));
        
        /*
         * TODO: You need to register and implement an OnClickListener for the "Send" button.
         * In your implementation you need to get the message from the input box (EditText)
         * and send it to other AVDs.
         */
        //Added By SAI


        Log.i(TAG, "Before socket creation");

        //Added By SAI
        /*
         * Calculate the port number that this AVD listens on.
         * It is just a hack that I came up with to get around the networking limitations of AVDs.
         * The explanation is provided in the PA1 spec.
         */
         TelephonyManager tel = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
         String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
         final String myPort = String.valueOf((Integer.parseInt(portStr) * 2));

        try {
            /*
             * Create a server socket as well as a thread (AsyncTask) that listens on the server
             * port.
             *
             * AsyncTask is a simplified thread construct that Android provides. Please make sure
             * you know how it works by reading
             * http://developer.android.com/reference/android/os/AsyncTask.html
             */
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            Log.i(TAG, "before socket function call");
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
        } catch (IOException e) {
            /*
             * Log is a good way to debug your code. LogCat prints out all the messages that
             * Log class writes.
             *
             * Please read http://developer.android.com/tools/debugging/debugging-projects.html
             * and http://developer.android.com/tools/debugging/debugging-log.html
             * for more information on debugging.
             */
            Log.i(TAG, "Can't create a ServerSocket");
            return;
        }


        //End Of Sai
        final EditText editText = (EditText) findViewById(R.id.editText1);


      //  String msg = editText.getText().toString() + "\n";
      //  TextView localTextView = (TextView) findViewById(R.id.local_text_display);
       // localTextView.append("\t" + msg); // This is one way to display a string.
        //TextView remoteTextView = (TextView) findViewById(R.id.remote_text_display);
        //remoteTextView.append("\n");




        /*
         * Note that the following AsyncTask uses AsyncTask.SERIAL_EXECUTOR, not
         * AsyncTask.THREAD_POOL_EXECUTOR as the above ServerTask does. To understand
         * the difference, please take a look at
         * http://developer.android.com/reference/android/os/AsyncTask.html
         */

//        findViewById(R.id.button1).setOnClickListener(
//                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, myPort)
//        );
         //Button mButton;
        Button  mButton = (Button) findViewById(R.id.button4);
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                // Do something
                Log.i("onlick","onclick");
                Log.i(TAG, "Enter key pressed");
                      String msg = editText.getText().toString() + "\n";
                      editText.setText(""); // This is one way to reset the input box.
                     // TextView localTextView = (TextView) findViewById(R.id.textView1);
                      //localTextView.append("\t" + msg); // This is one way to display a string.
                      //TextView remoteTextView = (TextView) findViewById(R.id.remote_text_display);
                      //remoteTextView.append("\n");

                     /*
//                     * Note that the following AsyncTask uses AsyncTask.SERIAL_EXECUTOR, not
//                     * AsyncTask.THREAD_POOL_EXECUTOR as the above ServerTask does. To understand
//                     * the difference, please take a look at
//                     * http://developer.android.com/reference/android/os/AsyncTask.html
//                     */
                     new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg, myPort);
//

            }
        });





    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
        return true;
    }
//Added By SAI

    /***
     * ServerTask is an AsyncTask that should handle incoming messages. It is created by
     * ServerTask.executeOnExecutor() call in SimpleMessengerActivity.
     *
     * Please make sure you understand how AsyncTask works by reading
     * http://developer.android.com/reference/android/os/AsyncTask.html
     *
     * @author stevko
     *
     */
    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {




        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];

            /*
             * TODO: Fill in your server code that receives messages and passes them
             * to onProgressUpdate().
             */
            //Added By SAI


            Log.i("inside socket","inside doInBackground");
            Socket socket = null;
            DataInputStream in = null;
            DataOutputStream out = null;
            CommonUtil cUtil = new CommonUtil();

            while(true)
            {


                try{

                    Log.i("inside while","whie");
                    //waiting for client to connect
                    socket = serverSocket.accept();
                    Log.i("In Server","connected to server "+socket.getRemoteSocketAddress());

                    //reading data from socket
                    in = new DataInputStream(socket.getInputStream());

                    //Reading from stream
                    String chat = in.readUTF();

                    if(cUtil.checkStringNull(chat))
                    {
                        Log.i("In Server : ","returned null by client");
                        continue;
                        //return null;
                    }

                    Log.i("Client says",chat);

                    //To display in UI
                    publishProgress(chat);



                    // sending msg to client close the socket to avoid EOF exception
                    out = new DataOutputStream(socket.getOutputStream());
                    out.writeUTF("over");
                    Log.i("In server","after Sending acknowledgement message");
                }
                catch (IOException e)
                {
                    Log.e("Server error " , e.getMessage());
                }
                finally {
                    cUtil.closeInputStream(in);
                    cUtil.closeOutputStream(out);
                    cUtil.closeSocket(socket);

                }

            }



            //End Of SAI






            // return null;
        }

        protected void onProgressUpdate(String...strings) {
            /*
             * The following code displays what is received in doInBackground().
             */
            String strReceived = strings[0].trim();
            //TextView remoteTextView = (TextView) findViewById(R.id.remote_text_display);
            TextView remoteTextView = (TextView) findViewById(R.id.textView1);

           // remoteTextView.append(strReceived + "\t\n");
            remoteTextView.append(strReceived+"\t\n");

            //TextView localTextView = (TextView) findViewById(R.id.local_text_display);
           // localTextView.append("\n");

            /*
             * The following code creates a file in the AVD's internal storage and stores a file.
             *
             * For more information on file I/O on Android, please take a look at
             * http://developer.android.com/training/basics/data-storage/files.html
             */
            try{


            Log.i(TAG, "onProgressUpdate");
           // String filename = "GroupMessenger";
            String string = strReceived + "\n";


            SEQ_NO = SEQ_NO+1;
            ContentValues values = new ContentValues();

               // cv[i].put(KEY_FIELD, "key" + Integer.toString(i));
                //cv[i].put(VALUE_FIELD, "val" + Integer.toString(i));
                values.put(KEY_FIELD, Integer.toString(SEQ_NO));
                values.put(VALUE_FIELD, string);

                //values.put("key"+SEQ_NO, string);
            String val = values.get("value").toString();
            Log.v("getval in server", val);
            String key = values.get("key").toString();
            Log.v("getkey in server", key);


                //mContentResolver.insert(mUri, mContentValues[i]);

            getContentResolver().insert(CONTENT_URI, values);
            Log.i("Server"," New message has  been added and SeqNumb"+SEQ_NO);
            }
            catch (NullPointerException e)
            {
                Log.e("Exception","inside server background"+e.toString());

            }
            // Toast.makeText(getBaseContext(), "New Record Inserted", Toast.LENGTH_LONG).show();

         //   FileOutputStream outputStream;
//
//            try {
//                outputStream = openFileOutput(filename, Context.MODE_PRIVATE);
//                outputStream.write(string.getBytes());
//                outputStream.close();
//            } catch (Exception e) {
//                Log.e(TAG, "File write failed");
//            }


//            ContentValues values = new ContentValues();
//
//            values.clear();
//            values.put(TaskContract.Columns.TASK,task);
//
//            Uri uri = TaskContract.CONTENT_URI;
//            getApplicationContext().getContentResolver().insert(uri,values);







            return;
        }
    }

    /***
     * ClientTask is an AsyncTask that should send a string over the network.
     * It is created by ClientTask.executeOnExecutor() call whenever OnKeyListener.onKey() detects
     * an enter key press event.
     *
     * @author stevko
     *
     */
    private class ClientTask extends AsyncTask<String, Void, Void> {



        @Override
        protected Void doInBackground(String... msgs) {
            try {
               // String remotePort = REMOTE_PORT0;
               // if (msgs[1].equals(REMOTE_PORT0))
                 //   remotePort = REMOTE_PORT1;



                for( String port:REMOTE_PORT)
                {
                    String remotePort = port;



                Log.i("In Client","remotePortNumb "+remotePort);

                Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(remotePort));

                String msgToSend = msgs[0];
                /*
                 * TODO: Fill in your client code that sends out a message.
                 */

                // Added By SAI
                Log.i("In Client", "connected to client with address " + socket.getRemoteSocketAddress() + " with port " + remotePort);
                Log.i("In Client", "message to Send " + msgToSend);


                DataInputStream in = null;
                DataOutputStream out = null;
                CommonUtil cUtil = new CommonUtil();

                try {
                    //sending data to socket
                    out = new DataOutputStream(socket.getOutputStream());
                    out.writeUTF(msgToSend);

                    // receiving msg to close socket
                    in = new DataInputStream(socket.getInputStream());



                    String closeMsg = in.readUTF();
                    Log.i("In Client", "closing socket At Client");


                    if (closeMsg.equals("over")) {

                        cUtil.closeInputStream(in);
                        cUtil.closeOutputStream(out);
                        cUtil.closeSocket(socket);

                    }


                }
                catch (IOException e)
                {

                    Log.e("In Client", "Inside try block catch");
                }



                //End Of SAI

                // socket.close();
                }

            } catch (UnknownHostException e) {
                Log.e("In Client", "ClientTask UnknownHostException");
            } catch (IOException e) {
                Log.e("In Client", "ClientTask socket IOException");
            }



            return null;
        }
    }
    //End Of SAI

}
