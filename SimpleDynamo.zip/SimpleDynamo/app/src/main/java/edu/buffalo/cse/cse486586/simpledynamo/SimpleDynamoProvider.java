package edu.buffalo.cse.cse486586.simpledynamo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Formatter;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.MergeCursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.TextView;

public class SimpleDynamoProvider extends ContentProvider {

	//variable and function declaration

	static final String TAG = SimpleDynamoProvider.class.getSimpleName();
	//static final String URL = "content://edu.buffalo.cse.cse486586.simpledynamo.provider";
	private  Uri mUri;

	//static final Uri CONTENT_URI = Uri.parse(URL);
	private Uri buildUri(String scheme, String authority) {
		Uri.Builder uriBuilder = new Uri.Builder();
		uriBuilder.authority(authority);
		uriBuilder.scheme(scheme);
		return uriBuilder.build();
	}
	 final Uri CONTENT_URI = buildUri("content", "edu.buffalo.cse.cse486586.simpledynamo.SimpleDynamoActivity");


	static int SEQ_NO = -1;
	static final int SERVER_PORT = 10000;
	private Integer selfClientPort;
	private Integer selfPId;
	private String selfPortHashedVal="";
	private final String LOCAL_PAIRS_QUERY = "@";
	private final String ALL_PAIRS_QUERY = "*";
	private final String ROOT_FOLDER="root_folder";
	private static final String KEY_FIELD = "key";
	private static final String VALUE_FIELD = "value";
	private static final String DELIMITER = ":";
	private final String CV_DELIMETER = "/";
	private static  final String ACK="server_ack";

	private static final String INSERT_KEY_INTO_CP = "req_insert_key_with_port";
	private static final String DELETE_ALL_KEY_OF_PORT_CP = "req_delete_all_file_in_port";
	private static final String DELETE_KEY_FROM_CP = "req_delete_key_with_port";
	private static final String DELETE_ALL_PAIR_CP = "delete_everything_in_cp";
	private static final String COLLECT_MY_DATE = "req_data_collect_while_recovery";
	private static final String CHECK_ALIVE = "r_u_alive";
	private static final String COLLECT_ALL_MESSAGES = "get_and_replicate";
	private String ALL_MESSAGES = "return_AllMsg";
	private String GET_ALL_VALUE = "req_all_keyValue";
	private String GET_VALUE = "req_value_for_key";
	private String FILE_VALUE = "return_file_value";
	static final String AVD_0 ="11108";
	static final String AVD_1 ="11112";
	static final String AVD_2 ="11116";
	static final String AVD_3 ="11120";
	static final String AVD_4 ="11124";
	static final String REMOTE_PORT[]= {AVD_0,AVD_1,AVD_2,AVD_3,AVD_4};
//	static final String REMOTE_PORT[]= {};

	private Integer SOCKET_TIMEOUT = 2500;
	Map<String, String[]> replicaMap = new HashMap<String, String[]>();
	Map<String, String> predMap = new HashMap<String, String>();
	Map<String, String> succMap = new HashMap<String, String>();
	Map<String, String[]> whichAllAvdDataStoreMap = new HashMap<String, String[]>();
	TreeMap<String,Node> Chord = new TreeMap<String,Node>();
	private final ReentrantLock reentrantLockObject = new ReentrantLock();
	public static final Object globalSyncObj = new Object();
	public class  Node{
		// selfClientPort = portStr;
		//selfPortHashedVal = genHash(selfClientPort);

		String self_ClientPort;
		String self_PortHashedVal;
		String pred_PortHashedVal;
		String pred_Port;
		String succ_PortHashedVal;
		String succ_Port;

		public void setAllValue(String self_ClientPort, String self_PortHashedVal, String pred_PortHashedVal, String pred_Port, String succ_PortHashedVal, String succ_Port) {
			this.self_ClientPort = self_ClientPort;
			this.self_PortHashedVal = self_PortHashedVal;
			this.pred_PortHashedVal = pred_PortHashedVal;
			this.pred_Port = pred_Port;
			this.succ_PortHashedVal = succ_PortHashedVal;
			this.succ_Port = succ_Port;
		}

		public String getSelf_ClientPort() {
			return self_ClientPort;
		}

		public void setSelf_ClientPort(String self_ClientPort) {
			this.self_ClientPort = self_ClientPort;
		}

		public String getSelf_PortHashedVal() {
			return self_PortHashedVal;
		}

		public void setSelf_PortHashedVal(String self_PortHashedVal) {
			this.self_PortHashedVal = self_PortHashedVal;
		}

		public String getPred_PortHashedVal() {
			return pred_PortHashedVal;
		}

		public void setPred_PortHashedVal(String pred_PortHashedVal) {
			this.pred_PortHashedVal = pred_PortHashedVal;
		}

		public String getPred_Port() {
			return pred_Port;
		}

		public void setPred_Port(String pred_Port) {
			this.pred_Port = pred_Port;
		}

		public String getSucc_PortHashedVal() {
			return succ_PortHashedVal;
		}

		public void setSucc_PortHashedVal(String succ_PortHashedVal) {
			this.succ_PortHashedVal = succ_PortHashedVal;
		}

		public String getSucc_Port() {
			return succ_Port;
		}

		public void setSucc_Port(String succ_Port) {
			this.succ_Port = succ_Port;
		}
	}

	private static Map<String, String[]> initializeAvdDataStore(){
		Map<String, String[]> map = new HashMap<String, String[]>();
		map.put(AVD_0, new String[]{AVD_1, AVD_4});
		map.put(AVD_1, new String[]{AVD_4, AVD_3});
		map.put(AVD_2, new String[]{AVD_0, AVD_1});
		map.put(AVD_3, new String[]{AVD_0, AVD_2});
		map.put(AVD_4, new String[]{AVD_3, AVD_2});
		return map;
	}




	private static Map<String, String[]> initializeReplicators(){
		Map<String, String[]> map = new HashMap<String, String[]>();
		map.put(AVD_0, new String[]{AVD_2, AVD_3});
		map.put(AVD_1, new String[]{AVD_0, AVD_2});
		map.put(AVD_2, new String[]{AVD_3, AVD_4});
		map.put(AVD_3, new String[]{AVD_4, AVD_1});
		map.put(AVD_4, new String[]{AVD_1, AVD_0});
		return map;
	}

	private static Map<String, String> initializePredecessorMap(){
		Map<String, String> map = new HashMap<String, String>();
		map.put(AVD_0, AVD_1);
		map.put(AVD_1, AVD_4);
		map.put(AVD_2, AVD_0);
		map.put(AVD_3, AVD_2);
		map.put(AVD_4, AVD_3);
		return map;
	}

	private static Map<String, String> initializeSuccessorMap(){
		Map<String, String> map = new HashMap<String, String>();
		map.put(AVD_0, AVD_2);
		map.put(AVD_1, AVD_0);
		map.put(AVD_2, AVD_3);
		map.put(AVD_3, AVD_4);
		map.put(AVD_4, AVD_1);
		return map;
	}

	//close main socket not included
	private String sendMessageUsingSocket(String msg, String destPort){



		try{

			String remotePort = destPort;
			Socket insertSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
					Integer.parseInt(remotePort));



			DataOutputStream dos = new DataOutputStream(insertSocket.getOutputStream());


			String msgToSend = msg;

			Log.i("In Server", "connected to client with address " + insertSocket.getRemoteSocketAddress() + " with port " + remotePort);
			Log.i("In server","sendMessageUsingSocket Msg " + msgToSend);

			dos.writeUTF(msgToSend);
			DataInputStream dis = new DataInputStream(insertSocket.getInputStream());
			//insertSocket.setSoTimeout(100);


			String resMsg = dis.readUTF();

			Log.i("In server","sendMessageUsingSocket  receivedMsg ");

			if(resMsg != null )
			{
				insertSocket.close();
				Log.i("In Server","Response received after sendMessageUsingSocket IN server");
				return resMsg;

//				DataOutputStream tempdos = new DataOutputStream(socket.getOutputStream());
//				tempdos.writeUTF(ACK);
//				tempdos.close();
////                                       socket.close();
			}
		}
		catch (Exception e){
			Log.i(TAG,"sendMessageUsingSocket msg error"+e.toString());
		}

		return "";
	}


public void storeChordInformation(){






	String keyHash_0 ="";
	String keyHash_1 ="";
	String keyHash_2 ="";
	String keyHash_3 ="";
	String keyHash_4 ="";

	//Integer.toString(int)
	try{
		keyHash_0 = genHash(Integer.toString(Integer.parseInt(AVD_0)/2));

		keyHash_1 = genHash(Integer.toString(Integer.parseInt(AVD_1)/2));

		keyHash_2 = genHash(Integer.toString(Integer.parseInt(AVD_2)/2));

		keyHash_3 = genHash(Integer.toString(Integer.parseInt(AVD_3)/2));

		keyHash_4 = genHash(Integer.toString(Integer.parseInt(AVD_4)/2));


		Log.i("Key hash: ",keyHash_0);
		Log.i("Key hash: ",keyHash_1);
		Log.i("Key hash: ",keyHash_2);
		Log.i("Key hash: ",keyHash_3);
		Log.i("Key hash: ",keyHash_4);
	}
	catch (Exception e)
	{
		Log.i(TAG,"not able to hash"+ e.getMessage());
		//e.printStackTrace();
	}


 	Node node0 = new Node();
	Node node1 = new Node();
	Node node2 = new Node();
	Node node3 = new Node();
	Node node4 = new Node();


	node0.setAllValue(AVD_0, keyHash_0, keyHash_1, AVD_1, keyHash_2, AVD_2);
	node1.setAllValue(AVD_1, keyHash_1, keyHash_4, AVD_4, keyHash_0, AVD_0);
	node2.setAllValue(AVD_2, keyHash_2, keyHash_0, AVD_0, keyHash_3, AVD_3);
	node3.setAllValue(AVD_3, keyHash_3, keyHash_2, AVD_2, keyHash_4, AVD_4);
	node4.setAllValue(AVD_4, keyHash_4, keyHash_3, AVD_3, keyHash_1, AVD_1);

	Chord.put(keyHash_0, node0);
	Chord.put(keyHash_1, node1);
	Chord.put(keyHash_2, node2);
	Chord.put(keyHash_3, node3);
	Chord.put(keyHash_4, node4);


}



public void collectMsgAndStore(String msgtoSend, String forWhichPort, String destPort){



    Log.e("inside Collect","msg = "+ msgtoSend +" collect for port "+ forWhichPort + "send to destprot "+ destPort);
    if(destPort != null && destPort != ""){



        String res = sendMessageUsingSocket(msgtoSend ,destPort);

        Log.e("recieved ","response "+ res);
        if(res != null && res != ""){
            String[] resSplit = res.split(DELIMITER);

            if(resSplit.length > 1 && resSplit[0].equals(COLLECT_ALL_MESSAGES)){

                String[] avdMsg = resSplit[1].split(CV_DELIMETER);
                for(int i=0; i < avdMsg.length -1; i+=2){


                    Log.e("store","key " +  avdMsg[i] + " value " + avdMsg[i+1]+" in folder "+ forWhichPort);
                   // cursor.newRow().add("key",avdMsg[i]).add("value",avdMsg[i+1]);
                    storeInCP(avdMsg[i],avdMsg[i],avdMsg[i+1],forWhichPort);

                }


            }


        } // res not null




    } // found port to replicate if end







}







public void createDirToStoreInCP(){


	try{

		File dir = new File(getContext().getApplicationInfo().dataDir + "/files/");

		//File dir = new File(Environment.getExternalStorageDirectory()+"Dir_name_here");
		if (dir.isDirectory())
		{
			String[] children = dir.list();
			for (int i = 0; i < children.length; i++)
			{
				new File(dir, children[i]).delete();
			}
		}




	}catch (Exception e){
		Log.i(TAG,"Exception at file delete");
	}



	File mainDir = new File(getContext().getApplicationInfo().dataDir + "/files" );

	Log.i(TAG,"print dataDir"+ getContext().getApplicationInfo().dataDir);

	if(!mainDir.exists())
		mainDir.mkdir();


		File selfFolder = new File(getContext().getApplicationInfo().dataDir + "/files/" + selfClientPort.toString());
		if (!selfFolder.exists())
			selfFolder.mkdir();

		List<String> targetNodes = new ArrayList<String>();

		Log.i(TAG, "selfClientPort " + selfClientPort);
		targetNodes.addAll(Arrays.asList(whichAllAvdDataStoreMap.get(selfClientPort.toString())));

		for (String port : targetNodes) {

			File createStructure = new File(getContext().getApplicationInfo().dataDir + "/files/" + port);

			if (!createStructure.exists())
				createStructure.mkdir();
		}




}

	public void storeInCP(String key_Hash,String contentKey, String contentVal, String remotePort){


		//write into file
		File Files = new File(getContext().getApplicationInfo().dataDir+"/files/" + remotePort + "/" + contentKey);

		//delete file before write
		if(Files.delete())
		{
			Log.v("Provider","delete of file successful "+ contentKey);
		}


		try{
//			FileOutputStream outputStream;
//			outputStream = getContext().openFileOutput(contentKey, Context.MODE_PRIVATE);
//			outputStream.write(contentVal.getBytes());
//			outputStream.close();


			BufferedWriter buf = new BufferedWriter(new FileWriter(Files, true));
			buf.append(contentVal);
			//buf.newLine();  // pointer will be nextline
			buf.close();


		}
		catch (IOException e)
		{
			Log.i("Exception","file write failed"+e.toString());
		}
	}



	private class ClientTask extends AsyncTask<String, Void, Void> {


		@Override
		protected Void doInBackground(String... msgs) {


			//synchronized (globalSyncObj){



			String  msgToSend ="" ;
			Socket socket = null;
			//String remotePort ="";


			String fromPortToCollect = "";
			//return null;


			List<String> targetNodes = new ArrayList<String>();

			Log.i(TAG, "selfClientPort " + selfClientPort);
			targetNodes.addAll(Arrays.asList(replicaMap.get(selfClientPort.toString())));

			for(String targetPort :targetNodes){
				//String targetPort = targetNodes[i];
				String msg = CHECK_ALIVE + DELIMITER+ selfClientPort.toString();
				String res = sendMessageUsingSocket(msg ,targetPort);

				if(res.equals(ACK)){
					fromPortToCollect = targetPort;
					break;
				}


			}



            String msgtoSend = COLLECT_MY_DATE + DELIMITER + selfClientPort.toString();


        //to replicate
         if(fromPortToCollect != null && fromPortToCollect != "")
            collectMsgAndStore(msgtoSend,selfClientPort.toString(),fromPortToCollect);


            List<String> getDataFromNode = new ArrayList<String>();

            getDataFromNode.addAll(Arrays.asList(whichAllAvdDataStoreMap.get(selfClientPort.toString())));

         //get other avd msgs
        for(String dataNode : getDataFromNode){

            String sendMsg = COLLECT_MY_DATE + DELIMITER + dataNode;
            collectMsgAndStore(sendMsg,dataNode,dataNode);
        }





			return null;

		//	} // end of Sync

		}//do in background end


		@Override
		protected void onPostExecute(Void aVoid) {
			super.onPostExecute(aVoid);
			//reentrantLockObject.unlock();

			if (reentrantLockObject.isHeldByCurrentThread()) {
				reentrantLockObject.unlock();
			}
		}




	}// ClientTask end



	private class ServerTask extends AsyncTask<ServerSocket, String, Void> {




		@Override
		protected Void doInBackground(ServerSocket... sockets) {
			ServerSocket serverSocket = sockets[0];


			//Added By SAI


			Log.i("inside socket","inside doInBackgrounds");
			Socket socket = null;
			DataInputStream in = null;
			DataOutputStream out = null;

			while(true)
			{

				reentrantLockObject.lock();
				if(reentrantLockObject.isHeldByCurrentThread())
					reentrantLockObject.unlock();
				try{


					//waiting for client to connect
					socket = serverSocket.accept();
					Log.i("In Server","connected to server "+socket.getRemoteSocketAddress());

					//reading data from socket
					in = new DataInputStream(socket.getInputStream());

					//Reading from stream
					String msg = in.readUTF();

					Log.i(TAG,"msg from client"+ msg);
					Log.e(TAG,"msg from client"+ msg);

					if(msg != null) {


						//synchronized (globalSyncObj){


						String[] ClientMsg = msg.split(DELIMITER);

						if (ClientMsg[0].equals(CHECK_ALIVE)) {

							DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
							dos.writeUTF(ACK);
							dos.close();
						} else if (ClientMsg[0].equals(COLLECT_MY_DATE)) {

							String folderName = ClientMsg[1];

							MatrixCursor res = getKeyFromFolder(folderName);

							String appendMsg = cursorToString(res);

							String sendAck = COLLECT_ALL_MESSAGES + DELIMITER + appendMsg;


							Log.e(TAG, " res for collect" + sendAck);
							DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
							dos.writeUTF(sendAck);
							dos.close();


						} else if (ClientMsg[0].equals(INSERT_KEY_INTO_CP)) {


							String key_Hash = ClientMsg[1];
							String contentKey = ClientMsg[2];
							String contentValue = ClientMsg[3];
							String remotePort = ClientMsg[4];

							storeInCP(key_Hash, contentKey, contentValue, remotePort);


							DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
							dos.writeUTF(ACK);
							dos.close();

						} else if (ClientMsg[0].equals(DELETE_ALL_KEY_OF_PORT_CP)) {

							String folderName = ClientMsg[1];

							deleteAllFileInFolder(folderName);

							DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
							dos.writeUTF(ACK);
							dos.close();

						}//all key of a avd
						else if (ClientMsg[0].equals(DELETE_ALL_PAIR_CP)) {

							deleteAllFileInFolder(ROOT_FOLDER);
							DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
							dos.writeUTF(ACK);
							dos.close();

						}//delete all
						else if (ClientMsg[0].equals(DELETE_KEY_FROM_CP)) {

							String fileName = ClientMsg[1];
							String folderName = ClientMsg[2];

							deleteFile(fileName, folderName);

							DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
							dos.writeUTF(ACK);
							dos.close();

						} //delete key of avd
						else if (ClientMsg[0].equals(GET_ALL_VALUE)) {

							Log.i("inside all", "query->" + ClientMsg[1]);
							//Log.i("inside all", "succ port" + routing_node.getSucc_Port());

							Cursor resultCursor = query(mUri, null,
									LOCAL_PAIRS_QUERY, null, null);


							Log.i("inside all", "if condition");


							String avdMessages = cursorToString(resultCursor);

							Log.i("inside all", "if with avd" + avdMessages);

							String resMsg = ALL_MESSAGES + DELIMITER + avdMessages;
							Log.i("inside all", "if with resMsg" + resMsg);


							DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
							dos.writeUTF(resMsg);
							dos.close();
							Log.i("inside all", "sent" + resMsg);

						} else if (ClientMsg[0].equals(GET_VALUE)) {


							//String key_Hash =clientMsg[2];


							Log.i(TAG, "Query into same  avd");
							//String ContentVal = clientMsg[3];
							String ContentKey = ClientMsg[1];
							String folderName = ClientMsg[3];
							// storeInCP(key_Hash,ContentKey,ContentVal);
//								StringBuilder fileValue = getFileValue(ContentKey, selfClientPort.toString());
							StringBuilder fileValue = getFileValue(ContentKey, folderName);

							//Log.e(TAG, "msg " + msg);
						//	Log.e(TAG, "filevalue " + fileValue);
							String resMsg = FILE_VALUE + DELIMITER + fileValue;
							Log.e(TAG,"sending " + resMsg);

							DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
							dos.writeUTF(resMsg);
							dos.close();


						}//end of getValue else if


						//		Log.i("Client says",msg);
						// sending msg to client close the socket to avoid EOF exception
//						out = new DataOutputStream(socket.getOutputStream());
//						out.writeUTF(ACK);
						//	Log.i("In server","after Sending acknowledgement message");


					//} //end of Sync
					} // End of msg not null if condition


				}
				catch (IOException e)
				{
					Log.e("Server error " , e.getMessage());
				}
				catch (Exception e)
				{
					Log.e("Server error " , e.getMessage());
				}


//				if(reentrantLockObject.isHeldByCurrentThread())
//					reentrantLockObject.unlock();


			}
			//End Of SAI
		}

		protected void onProgressUpdate(String...strings) {
			return;
		}
	}//ServerTask Ended


public void deleteAllFileInFolder(String folderName){



	try{

		if(folderName.equals(ROOT_FOLDER)){
			createDirToStoreInCP();
			return;
		}

		File dir = new File(getContext().getApplicationInfo().dataDir+"/files/"+ folderName+"/");

		//File dir = new File(getContext().getApplicationInfo().dataDir + "/files/");
		for(File file: dir.listFiles())
			if (!file.isDirectory())
				file.delete();


	}catch (Exception e){
		Log.i(TAG,"Exception at file delete");
	}

}

public void  deleteFile(String fileName, String folderName){


	File file = new File(getContext().getApplicationInfo().dataDir+"/files/"+ folderName+"/"+fileName);

	if(file.delete())
	{
		Log.i(TAG,"File deleted successfully");
	}
	else
	{
		Log.i(TAG,"Failed to delete the file");
	}

}
	public String cursorToString(Cursor resultCursor){




		Cursor result = resultCursor;

		StringBuilder sb = new StringBuilder();

		int keyIndex = resultCursor.getColumnIndex(KEY_FIELD);
		int valueIndex = resultCursor.getColumnIndex(VALUE_FIELD);
		if (resultCursor != null) {
			// move cursor to first row
			if (resultCursor.moveToFirst()) {
				do {


					String returnKey = resultCursor.getString(0);
					String returnValue = resultCursor.getString(1);

					sb.append(returnKey);
					sb.append(CV_DELIMETER);
					sb.append(returnValue);
					sb.append(CV_DELIMETER);

					// Log.e(TAG,"key -> " + returnKey);

//                    Log.e(TAG,"val -> " + returnValue);

				} while (resultCursor.moveToNext());
			}
		} //resultCursor not null check
		if(sb.length() > 0){
			sb.deleteCharAt(sb.length() - 1);
		}

		return sb.toString();
	}

	public StringBuilder getFileValue(String selection, String folderName){

		Log.i("query", selection);
		Log.i("Directory",getContext().getApplicationInfo().dataDir);


		File f = new File(getContext().getApplicationInfo().dataDir+"/files/"+folderName);


		File[] list= f.listFiles();

		StringBuilder sb = new StringBuilder();
		for(File fil:list)
		{
			if(fil.getName().equals(selection))
			{
				Log.i("SearchFile","found file "+selection);

				try{

					FileInputStream fis = new FileInputStream(getContext().getApplicationInfo().dataDir+"/files/"+ folderName+"/"+selection);

				//	FileInputStream fis = getContext().openFileInput(selection);
					InputStreamReader isr = new InputStreamReader(fis);
					BufferedReader bufferedReader = new BufferedReader(isr);

					String line;
					while ((line = bufferedReader.readLine()) != null) {
						sb.append(line);
					}

					Log.i("value in file", String.valueOf(sb));


					// cursor.newRow().add("key",selection).add("value",sb);
					return sb;

				}
				catch (FileNotFoundException e)
				{
					Log.e("Exception","file read failed"+e.toString());
				}
				catch (IOException e)
				{
					Log.e("Exception","IOEXception"+ e.toString());
				}

				break;
			}

		}

		return sb;


	}







public MatrixCursor getKeyFromFolder(String folderName){
	MatrixCursor cursor = new MatrixCursor(
			new String[] {"key", "value"}
	);
	File f = new File(getContext().getApplicationInfo().dataDir+"/files/"+ folderName);

	Log.i("SearchFile","found file "+f.getName());

	if( !f.isDirectory()) // if dir is not present
		return cursor;

	File[] list= f.listFiles();

	//empty dir
	if(list.length < 1)
		return cursor;

	for(File fil:list)
	{

		String fileName = fil.getName();
		Log.i("SearchFile","found file "+fileName);

		try{

			FileInputStream fis = new FileInputStream(getContext().getApplicationInfo().dataDir+"/files/"+ folderName+"/"+fileName);
			//FileInputStream fis = getContext().openFileInput(fileName);
			InputStreamReader isr = new InputStreamReader(fis);
			BufferedReader bufferedReader = new BufferedReader(isr);
			StringBuilder sb = new StringBuilder();
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				sb.append(line);
			}

			//    Log.i("value in file", String.valueOf(sb));



			cursor.newRow().add("key",fileName).add("value",sb);


		}
		catch (FileNotFoundException e)
		{
			Log.i("Exception","file read failed"+e.toString());
		}
		catch (IOException e)
		{
			Log.i("Exception","IOEXception"+ e.toString());
		}


	} // end of file traversal for



	return cursor;
}


	public static HashMap<String, Integer> sortByValue(HashMap<String, Integer> hm)
	{
		// Create a list from elements of HashMap
		List<Map.Entry<String, Integer> > list =
				new LinkedList<Map.Entry<String, Integer> >(hm.entrySet());

		// Sort the list
		Collections.sort(list, new Comparator<Map.Entry<String, Integer> >() {
			public int compare(Map.Entry<String, Integer> o1,
							   Map.Entry<String, Integer> o2)
			{
				return (o2.getValue()).compareTo(o1.getValue());
			}
		});

		// put data from sorted list to hashmap
		HashMap<String, Integer> temp = new LinkedHashMap<String, Integer>();
		for (Map.Entry<String, Integer> aa : list) {
			temp.put(aa.getKey(), aa.getValue());
		}
		return temp;
	}





//end of variable and function declaration









	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub



		//synchronized (globalSyncObj){
		if (selection.contains(LOCAL_PAIRS_QUERY)) {

			try {
				File dir = new File(getContext().getApplicationInfo().dataDir + "/files/" + selfClientPort.toString() + "/");

				//File dir = new File(getContext().getApplicationInfo().dataDir + "/files/");
				for (File file : dir.listFiles())
					if (!file.isDirectory())
						file.delete();


			} catch (Exception e) {
				Log.i(TAG, "Exception at file delete");
			}


			List<String> targetNodes = new ArrayList<String>();


			targetNodes.addAll(Arrays.asList(replicaMap.get(selfClientPort.toString())));

			for (String remotePort : targetNodes) {

				String msgToSend = DELETE_ALL_KEY_OF_PORT_CP + DELIMITER + selfClientPort.toString();


				sendMessageUsingSocket(msgToSend, remotePort);


			}


		}// base if case end
		else if (selection.equals(ALL_PAIRS_QUERY)) {


			deleteAllFileInFolder(ROOT_FOLDER);


			for (String remotePort : REMOTE_PORT) {

				String msgToSend = DELETE_ALL_PAIR_CP + DELIMITER + selfClientPort.toString();

				if (!remotePort.equals(selfClientPort.toString())) // not self port
					sendMessageUsingSocket(msgToSend, remotePort);


			}


		} // all query end else if
		else {

			String contentKey = selection;
			String key_Hash = "";

			try {
				key_Hash = genHash(selection);
			} catch (Exception e) {
				e.printStackTrace();
			}

			List<String> targetNodes = new ArrayList<String>();

			String destPort = "";
			for (Map.Entry<String, Node>
					entry : Chord.entrySet()) {


				Node routing_node = entry.getValue();

				if (
						(routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >= 0
								&& routing_node.getPred_PortHashedVal().compareTo(key_Hash) <= 0)

								|| (routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
								&& routing_node.getPred_PortHashedVal().compareTo(key_Hash) <= 0)

								|| (routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
								&& routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >= 0)
				) {

					destPort = routing_node.getSelf_ClientPort();
					break;
				}

			}


			Log.i(TAG, "destPort of msg " + destPort);


			if (destPort != "") {


				targetNodes.addAll(Arrays.asList(replicaMap.get(destPort)));

				targetNodes.add(destPort);

				for (String remotePort : targetNodes) {

					if (remotePort.equals(selfClientPort.toString())) {


						deleteFile(contentKey, destPort);
						//storeInCP(key_Hash,contentKey,contentValue, remotePort);

					} else {
						String msgToSend = DELETE_KEY_FROM_CP + DELIMITER + contentKey + DELIMITER
								+ destPort;

						sendMessageUsingSocket(msgToSend, remotePort);
					}

				}
			}// dest port check


		} // single key else condition ended


	//}//end of sync



		return 0;
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// TODO Auto-generated method stub



		//synchronized (globalSyncObj){

		String contentKey = (String) values.get(KEY_FIELD);
		String contentValue = (String) values.get(VALUE_FIELD);
		String key_Hash = "";

		reentrantLockObject.lock();
		if (reentrantLockObject.isHeldByCurrentThread())
			reentrantLockObject.unlock();

		try {
			key_Hash = genHash(contentKey);
		} catch (Exception e) {
			e.printStackTrace();
		}

		List<String> targetNodes = new ArrayList<String>();

		String destPort = "";
		for (Map.Entry<String, Node>
				entry : Chord.entrySet()) {


			Node routing_node = entry.getValue();

			if (
					(routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >= 0
							&& routing_node.getPred_PortHashedVal().compareTo(key_Hash) <= 0)

							|| (routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
							&& routing_node.getPred_PortHashedVal().compareTo(key_Hash) <= 0)

							|| (routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
							&& routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >= 0)
			) {

				destPort = routing_node.getSelf_ClientPort();
				break;
			}

		}


		Log.i(TAG, "destPort of msg " + destPort);


		if (destPort != "") {


			targetNodes.addAll(Arrays.asList(replicaMap.get(destPort)));

			targetNodes.add(destPort);

			for (String remotePort : targetNodes) {


				//	Log.e(TAG, "insert  msg " + contentKey + " in avdPort " + remotePort+" folder name "+ destPort);


				if (remotePort.equals(selfClientPort.toString())) {

					//	synchronized (this){


					storeInCP(key_Hash, contentKey, contentValue, destPort);
					//	}

				} else {
					String msgToSend = INSERT_KEY_INTO_CP + DELIMITER + key_Hash + DELIMITER
							+ contentKey + DELIMITER + contentValue
							+ DELIMITER + destPort;
					//synchronized (this) {

					sendMessageUsingSocket(msgToSend, remotePort);
					//}
				}

			} // end of Sync
		}// dest port check


	//}
		return null;
	}

	@Override
	public boolean onCreate() {
		// TODO Auto-generated method stub
		reentrantLockObject.lock();

		mUri = buildUri("content", "edu.buffalo.cse.cse486586.simpledynamo.provider");


		TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
		final String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
		selfClientPort = (Integer.parseInt(portStr) * 2);
		selfPId = (selfClientPort - 11108) / 4;

		replicaMap = initializeReplicators();
		predMap = initializePredecessorMap();
		succMap = initializeSuccessorMap();
		whichAllAvdDataStoreMap = initializeAvdDataStore();

		storeChordInformation();

		createDirToStoreInCP();

		Log.i(TAG,"after createDirInCP");


		//serverTask

		try {
			ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
			Log.i(TAG, "before socket function callssss");
			new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
		} catch (IOException e) {
			Log.i(TAG, "Can't create a ServerSocket" + e.toString());

		}


		//ClientTask

		String msg="";
		new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msg,selfClientPort.toString());
		if(reentrantLockObject.isHeldByCurrentThread())
			reentrantLockObject.unlock();
		return false;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		// TODO Auto-generated method stub

	//	synchronized (globalSyncObj){
		Log.e(TAG, " key to query" + selection);
		MatrixCursor cursor = new MatrixCursor(
				new String[]{"key", "value"}
		);
		MergeCursor temp_Cursor = new MergeCursor(new Cursor[]{cursor});

		reentrantLockObject.lock();
		if (reentrantLockObject.isHeldByCurrentThread())
			reentrantLockObject.unlock();
//		return mergeCursor;
		if (selection.contains(LOCAL_PAIRS_QUERY)) {


			List<String> targetNodes = new ArrayList<String>();

			Log.i(TAG, "selfClientPort " + selfClientPort);
			targetNodes.addAll(Arrays.asList(whichAllAvdDataStoreMap.get(selfClientPort.toString())));

			targetNodes.add(selfClientPort.toString());
			//String port = selfClientPort.toString();
			for (String port : targetNodes) {

				//	synchronized (this) {

				Cursor resultCursor = getKeyFromFolder(port);


				temp_Cursor = new MergeCursor(new Cursor[]{temp_Cursor, resultCursor});
				//	}

			}


			MergeCursor res = temp_Cursor;
			//   int keyIndex = resultCursor.getColumnIndex(KEY_FIELD);
			//  int valueIndex = resultCursor.getColumnIndex(VALUE_FIELD);
			if (temp_Cursor != null) {
				// move cursor to first row
				if (temp_Cursor.moveToFirst()) {
					do {


						String returnKey = temp_Cursor.getString(0);
						String returnValue = temp_Cursor.getString(1);

						// Log.e(TAG,"key -> " + returnKey);

//						   Log.e(TAG,"val -> " + returnValue);

						//indexCount++;
						// move to next row
					} while (temp_Cursor.moveToNext());
				}
			} //resultCursor not null check

			return res;

		} //end of routing selfnode if
		else if (selection.contains(ALL_PAIRS_QUERY)) {


			Log.e(TAG, "call @ from *");

			Cursor resultCursor = this.query(mUri, null,
					LOCAL_PAIRS_QUERY, null, null);


			Cursor result = resultCursor;
			//   int keyIndex = resultCursor.getColumnIndex(KEY_FIELD);
			//  int valueIndex = resultCursor.getColumnIndex(VALUE_FIELD);
			if (resultCursor != null) {
				// move cursor to first row
				if (resultCursor.moveToFirst()) {
					do {


						String returnKey = resultCursor.getString(0);
						String returnValue = resultCursor.getString(1);

						//      Log.e(TAG,"key -> " + returnKey);

						//    Log.e(TAG,"val -> " + returnValue);

						//indexCount++;
						// move to next row
					} while (resultCursor.moveToNext());
				}
			} //resultCursor not null check


			MergeCursor mergeCursor = new MergeCursor(new Cursor[]{result});
			for (String port : REMOTE_PORT) {


				//create a socket and req for all pair query
				String msgToSend;
				//Socket socket ;
				String remotePort;

				remotePort = port;


				if (remotePort.equals(selfClientPort))
					continue;


				Log.e("In Query", " for * remotePortNumb " + remotePort);


				try {


					msgToSend = GET_ALL_VALUE + DELIMITER + remotePort;

					String closeMsg;

					//	synchronized (this) {
					closeMsg = sendMessageUsingSocket(msgToSend, remotePort);
					//	}

					Log.e("In Query", "closing socket at query" + closeMsg);


					if (closeMsg != null) {


						Log.e(TAG, "ACK received for * ");

						Log.e(TAG, closeMsg);

						String[] allMsg = closeMsg.split(DELIMITER);

						if (allMsg.length < 2) {
							continue;
//						return result;
						}


						Log.e(TAG, "allMsg length" + allMsg.length);
						String[] keyvalMsg = allMsg[1].split(CV_DELIMETER);

						Log.e(TAG, "length" + keyvalMsg.length);
						for (int i = 0; i < keyvalMsg.length - 1; i += 2) {

							cursor.newRow().add("key", keyvalMsg[i]).add("value", keyvalMsg[i + 1]);


						}

						mergeCursor = new MergeCursor(new Cursor[]{cursor, mergeCursor});


						//return mergeCursor;
					}


				} catch (Exception e) {

					Log.e("In Query", "Inside try block catch" + e.toString());
				}

			}


			return mergeCursor;
		} // end of all pair query
		else {

			Log.e(TAG, " key to query" + selection);


			//if(!selection.contains("*")){

			String key = selection;
			String key_Hash = "";

			try {
				key_Hash = genHash(selection);
				Log.i("Key hash: ", key_Hash);
			} catch (Exception e) {
				e.printStackTrace();
			}


			String destPort = "";
			for (Map.Entry<String, Node>
					entry : Chord.entrySet()) {


				Node routing_node = entry.getValue();

				if (
						(routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >= 0
								&& routing_node.getPred_PortHashedVal().compareTo(key_Hash) <= 0)

								|| (routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
								&& routing_node.getPred_PortHashedVal().compareTo(key_Hash) <= 0)

								|| (routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
								&& routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >= 0)
				) {

					destPort = routing_node.getSelf_ClientPort();
					break;
				}

			}

			Log.e(TAG, "dest port" + destPort);

			//with voting

			//Map<String, Integer> freqMap = new HashMap<String, Integer>();

			HashMap<String, Integer> freqMap = new HashMap<String, Integer>();
			//sortByValue
			List<String> targetNodes = new ArrayList<String>();
//
			targetNodes.add(destPort);
				targetNodes.addAll(Arrays.asList(replicaMap.get(destPort)));

			String msgToSend ;
			for (String targetPort : targetNodes) {

				try{


				if (targetPort.equals(selfClientPort)) {

					StringBuilder fileValue;

					//synchronized (this) {

					fileValue = getFileValue(selection, destPort);


					if (fileValue.toString() != null && fileValue.toString() != "") {


						Integer count = freqMap.get(fileValue);

						if (count == null) {
							freqMap.put(fileValue.toString(), 0);
						} else {

							count++;
							freqMap.put(fileValue.toString(), count);
						}
					}
					continue;
				}//self check


				msgToSend = GET_VALUE + DELIMITER + key
						+ DELIMITER + key_Hash + DELIMITER + destPort;
				Log.e("In Query", "msgToSend  at query" + msgToSend);
//
				String closeMsg;

//
				closeMsg = sendMessageUsingSocket(msgToSend, targetPort);
				Log.e(TAG,"received " + closeMsg);
				if (closeMsg != null) {
					String[] clientMsg = closeMsg.split(DELIMITER);

					Integer count = freqMap.get(clientMsg[1]);

					if (count == null) {
						freqMap.put(clientMsg[1], 0);
					} else {

						count++;
						freqMap.put(clientMsg[1], count);
					}

//					}
//
//
				}

			}
				catch ( Exception e){
					Log.i(TAG,"exe-> " +e.getMessage());
				}

			}




		if(freqMap.isEmpty())
			return cursor;


			Map<String, Integer> valueSotredMap = sortByValue(freqMap);

			String r = valueSotredMap.keySet().toArray()[0].toString();
			cursor.newRow().add("key", selection).add("value", r);
			//	return cursor;





			//without voting
//			if (destPort.equals(selfClientPort)) {
//
//				StringBuilder fileValue;
//
//				//synchronized (this) {
//
//				fileValue = getFileValue(selection, destPort);
//				//}
//				cursor.newRow().add("key", selection).add("value", fileValue);
//				return cursor;
//
//			} else {
//
//
//				List<String> targetNodes = new ArrayList<String>();
//
//				Log.i(TAG, "selfClientPort " + selfClientPort);
//				targetNodes.add(destPort);
//				targetNodes.addAll(Arrays.asList(replicaMap.get(destPort)));
//
//
////            targetNodes
//
//
//				String alivePort = "";
//				for (String targetPort : targetNodes) {
//					//String targetPort = targetNodes[i];
//					String msg = CHECK_ALIVE + DELIMITER + selfClientPort.toString();
//
//					String res;
//					//synchronized (this) {
//
//					res = sendMessageUsingSocket(msg, targetPort);
//					//}
//
//					if (res.equals(ACK)) {
//						alivePort = targetPort;
//						break;
//					}
//
//
//				}
//
//
//				String msgToSend;
//				//Socket socket ;
//				String remotePort;
//
////				remotePort =  destPort;
//				remotePort = alivePort;
//				Log.e("In Query", "remotePortNumb " + remotePort);
//
//
//				try {
//
//					//socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
//					//		Integer.parseInt(remotePort));
//
//
////					Log.e("In Query", "connected to client with address " + socket.getRemoteSocketAddress() + " with port " + remotePort);
//
//					msgToSend = GET_VALUE + DELIMITER + key
//							+ DELIMITER + key_Hash + DELIMITER + destPort;
//					Log.e("In Query", "msgToSend  at query" + msgToSend);
//
//					String closeMsg;
//					//	synchronized (this) {
//
//					closeMsg = sendMessageUsingSocket(msgToSend, remotePort);
//					//	}
//
//
////					String closeMsg = in.readUTF();
//					Log.e("In Query", "closing socket at query" + closeMsg);
//
//
//					if (closeMsg != null) {
//						String[] clientMsg = closeMsg.split(DELIMITER);
//
//
//						cursor.newRow().add("key", selection).add("value", clientMsg[1]);
//
//
//						//socket.close();
//						return cursor;
//					}
//
//
//				} catch (Exception e) {
//
//					Log.e("In Query", "Inside try block catch" + e.toString());
//				}
//
//
//				// return cursor;
//
//			}//end of else


		} // end of else particular key

	//}//end of Sync
		return cursor;
			//return null;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }


}
