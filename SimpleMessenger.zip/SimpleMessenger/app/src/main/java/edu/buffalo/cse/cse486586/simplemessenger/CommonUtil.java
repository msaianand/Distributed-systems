package edu.buffalo.cse.cse486586.simplemessenger;

import android.util.Log;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
//Added By SAI
public class CommonUtil {


    public void closeSocket(Socket socket)
    {
        try{
            if(!socket.isClosed()) {
                socket.close();
            }
        }
        catch (IOException e)
        {

            Log.e("Closing Socket error" , e.getMessage());
        }

    }

    public void closeInputStream(DataInputStream in)
    {
        try{

            if(in != null)
                in.close();


        }
        catch(IOException e)
        {
            Log.e("close Inputstream error" , e.getMessage());

        }

    }


    public void closeOutputStream(DataOutputStream out)
    {
        try{

            if(out != null)
                out.close();


        }
        catch(IOException e)
        {
            Log.e("close Outputstream error" , e.getMessage());

        }

    }

    public boolean checkStringNull(String s) {
        if (s == null || s.equalsIgnoreCase(null) || s.equalsIgnoreCase("")) {
            return true;
        }
        return false;
    }

}
