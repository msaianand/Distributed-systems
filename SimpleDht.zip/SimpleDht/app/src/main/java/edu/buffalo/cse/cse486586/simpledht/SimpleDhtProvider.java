package edu.buffalo.cse.cse486586.simpledht;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.ECField;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
//import org.apache.commons.io.FileUtils;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.MergeCursor;
import android.net.Uri;
import android.nfc.Tag;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.TextView;

public class SimpleDhtProvider extends ContentProvider {



    static final String TAG = SimpleDhtProvider.class.getSimpleName();
    static final String URL = "content://edu.buffalo.cse.cse486586.simpledht.provider";
     static final Uri CONTENT_URI = Uri.parse(URL);
//    private Uri buildUri(String scheme, String authority) {
//        Uri.Builder uriBuilder = new Uri.Builder();
//        uriBuilder.authority(authority);
//        uriBuilder.scheme(scheme);
//        return uriBuilder.build();
//    }
//    private Uri mUri = buildUri("content", "edu.buffalo.cse.cse486586.simpledht.provider");

    static int SEQ_NO = -1;
    static final int SERVER_PORT = 10000;
    private String selfClientPort="";
    private String selfPortHashedVal="";
    private final String LOCAL_PAIRS_QUERY = "@";
    private final String ALL_PAIRS_QUERY = "*";
    private static final String KEY_FIELD = "key";
    private static final String VALUE_FIELD = "value";
    private static final String DELIMITER = ":";
    private static final String JOIN_REQ = "req_join";
    static  final String MASTER_AVD = "11108";
    private static  final String ACK = "received message";
    private static final String UPDATE_ROUTING_NODE = "req_updateRnode";
    private String REQ_INSERT = "req_insert";
    private String CHECK_ALIVE = "Ping_Msg";
    private  String BUILD_CHORD = "req_build";
    private  String PASS_OR_INSERT = "req_pass_or_insert";
    private String PASS_OR_DELETE ="req_pass_or_delete";
    private String GET_VALUE = "req_value_for_key";
    private String GET_ALL_VALUE = "req_all_keyValue";
    private String DELETE_ALL_VALUE = "req_del_allValue";
    private String FILE_VALUE = "return_file_value";
    private String ALL_MESSAGES = "return_AllMsg";
    private  String SELF_JOIN_REQ = "req_self_join";
    private final String CV_DELIMETER = "/";
    Node routing_node = new Node();
    TreeMap<String,Node> Chord = new TreeMap<String,Node>();

    static final String REMOTE_PORT[]= {"11108","11112","11116","11120","11124"};

    private  Uri mUri;
    private Uri buildUri(String scheme, String authority) {
        Uri.Builder uriBuilder = new Uri.Builder();
        uriBuilder.authority(authority);
        uriBuilder.scheme(scheme);
        return uriBuilder.build();
    }

    public class  Node{
       // selfClientPort = portStr;
        //selfPortHashedVal = genHash(selfClientPort);

        String self_ClientPort;
        String self_PortHashedVal;
        String pred_PortHashedVal;
        String pred_Port;
        String succ_PortHashedVal;
        String succ_Port;

        public void setAllValue(String self_ClientPort, String self_PortHashedVal, String pred_PortHashedVal, String pred_Port, String succ_PortHashedVal, String succ_Port) {
            this.self_ClientPort = self_ClientPort;
            this.self_PortHashedVal = self_PortHashedVal;
            this.pred_PortHashedVal = pred_PortHashedVal;
            this.pred_Port = pred_Port;
            this.succ_PortHashedVal = succ_PortHashedVal;
            this.succ_Port = succ_Port;
        }

        public String getSelf_ClientPort() {
            return self_ClientPort;
        }

        public void setSelf_ClientPort(String self_ClientPort) {
            this.self_ClientPort = self_ClientPort;
        }

        public String getSelf_PortHashedVal() {
            return self_PortHashedVal;
        }

        public void setSelf_PortHashedVal(String self_PortHashedVal) {
            this.self_PortHashedVal = self_PortHashedVal;
        }

        public String getPred_PortHashedVal() {
            return pred_PortHashedVal;
        }

        public void setPred_PortHashedVal(String pred_PortHashedVal) {
            this.pred_PortHashedVal = pred_PortHashedVal;
        }

        public String getPred_Port() {
            return pred_Port;
        }

        public void setPred_Port(String pred_Port) {
            this.pred_Port = pred_Port;
        }

        public String getSucc_PortHashedVal() {
            return succ_PortHashedVal;
        }

        public void setSucc_PortHashedVal(String succ_PortHashedVal) {
            this.succ_PortHashedVal = succ_PortHashedVal;
        }

        public String getSucc_Port() {
            return succ_Port;
        }

        public void setSucc_Port(String succ_Port) {
            this.succ_Port = succ_Port;
        }
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub

        if (routing_node.getSucc_PortHashedVal() == null
                || routing_node.getPred_PortHashedVal() == null
                || routing_node.getSelf_PortHashedVal() == null
                || selection.contains(LOCAL_PAIRS_QUERY)){

            try{

                File dir = new File(getContext().getApplicationInfo().dataDir + "/files/");
                for(File file: dir.listFiles())
                    if (!file.isDirectory())
                        file.delete();


            }catch (Exception e){
                Log.i(TAG,"Exception at file delete");
            }

        }// base if case end
        else if(selection.contains(ALL_PAIRS_QUERY)){




            Log.e(TAG, "call @ from * in delete");

            this.delete(mUri,LOCAL_PAIRS_QUERY,  null);
            if(routing_node.getSucc_PortHashedVal() == null
                    || routing_node.getPred_PortHashedVal() == null
                    || routing_node.getSelf_PortHashedVal() == null
                    ||  routing_node.getSelf_ClientPort().equals(routing_node.getPred_Port())
                    ||  routing_node.getSelf_ClientPort().equals(routing_node.getSucc_Port())

            ){

                return 0;
            } // if only one AVD




            //create a socket and req for all pair query
            String  msgToSend  ;
            Socket socket ;
            String remotePort ;

            remotePort =  routing_node.getSucc_Port();

            Log.e("In delete"," for * remotePortNumb "+remotePort);



            try {

                socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(remotePort));


                Log.e("In delete", "connected to client with address " + socket.getRemoteSocketAddress() + " with port " + remotePort);

                msgToSend =DELETE_ALL_VALUE + DELIMITER + routing_node.getSelf_ClientPort();

                Log.e("In Delete", "message to Send " + msgToSend);
//                Log.i("In Insert", "connected to client with address " + insertSocket.getRemoteSocketAddress() + " with port " + remotePort);
                //Log.i("In Delete", "message to Send " + msgToSend);
//
                DataInputStream in = null;
                DataOutputStream out = null;




                //sending data to socket
                out = new DataOutputStream(socket.getOutputStream());
                out.writeUTF(msgToSend);
                // receiving msg to close socket
                in = new DataInputStream(socket.getInputStream());



                String closeMsg = in.readUTF();
                Log.e("In Delete", "closing socket at query"+ closeMsg);


                if (closeMsg != null) {

                    Log.e(TAG,"ACK received for * in delete");
                    Log.e(TAG,closeMsg);
                    socket.close();

                }


            }

            catch (Exception e)
            {

                Log.e("In Delete", "Inside try block catch"+ e.toString());
            }


        } // end of all delete
        else{




            String key_Hash="";

            try{
                key_Hash=genHash(selection);
                Log.i("Key hash: ",key_Hash);
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            Log.i(TAG,"inside insert");


            if(routing_node.getSelf_PortHashedVal() != null &&
                    routing_node.getPred_PortHashedVal() != null &&
                    routing_node.getSucc_PortHashedVal() != null){


                Log.i(TAG,"self and key"+ routing_node.getSelf_PortHashedVal().compareTo(key_Hash) );
                Log.i(TAG,"pred and key"+ routing_node.getPred_PortHashedVal().compareTo(key_Hash) );
                Log.i(TAG,"pred and curr" +routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()));
            }
            if(routing_node.getPred_PortHashedVal() == null ||
                    routing_node.getSelf_PortHashedVal() == null ||
                    routing_node.getSelf_PortHashedVal() == null
                    || routing_node.getPred_Port().equals(selfClientPort)
                    || routing_node.getSucc_Port().equals(selfClientPort) ||

                    (routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >= 0
                            && routing_node.getPred_PortHashedVal().compareTo(key_Hash) <=0)

                    || ( routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
                    && routing_node.getPred_PortHashedVal().compareTo(key_Hash) <=0 )

                    || ( routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
                    && routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >=0 )
            ){

                Log.e(TAG,"inside if");
                //delete file


                deleteFromCP(selection);


            }
            else{

                String  msgToSend ="" ;
                Socket socket = null;
                String remotePort ="";

                remotePort =  routing_node.getSucc_Port();

                Log.e("In delete","remotePortNumb "+remotePort);



                try {

                    socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(remotePort));


                    Log.i("In Client", "connected to client with address " + socket.getRemoteSocketAddress() + " with port " + remotePort);

                    msgToSend =PASS_OR_DELETE + DELIMITER + selection
                            + DELIMITER + key_Hash;
                    Log.e("In delete", "message to Send " + msgToSend);
//                Log.i("In Insert", "connected to client with address " + insertSocket.getRemoteSocketAddress() + " with port " + remotePort);
//                Log.i("In Insert", "message to Send " + msgToSend);
//
                    DataInputStream in = null;
                    DataOutputStream out = null;




                    //sending data to socket
                    out = new DataOutputStream(socket.getOutputStream());
                    out.writeUTF(msgToSend);
//                socket.setSoTimeout(2000);
                    // receiving msg to close socket
                    in = new DataInputStream(socket.getInputStream());



                    String closeMsg = in.readUTF();
                    Log.e("In delete", "closing socket At Client");


                    if (closeMsg.equals(ACK)) {

                        socket.close();
                    }


                }

                catch (Exception e)
                {

                    Log.i("In Insert", "Inside try block catch"+ e.toString());
                }


            }// End of Hasvalue compare else if













        }




        return 0;
    }

    @Override
    public String getType(Uri uri) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        // TODO Auto-generated method stub



//        String key = values.get("key").toString();
//        String key_value = values.get("value").toString();
        String key_Hash="";

        try{
            key_Hash=genHash(values.get("key").toString());
            Log.i("Key hash: ",key_Hash);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    Log.i(TAG,"inside insert");

////        Log.i(TAG,"self"+selfClientPort);
//        Log.i(TAG,"selfhash "+routing_node.getSelf_PortHashedVal());
//
////        Log.i(TAG,"pred"+routing_node.getPred_Port());
//
//        Log.i(TAG,"PredHash "+routing_node.getPred_PortHashedVal());
////        Log.i(TAG,"suc"+routing_node.getSucc_Port());
//
//        Log.i(TAG,"SucHash "+routing_node.getSucc_PortHashedVal());
//
if(routing_node.getSelf_PortHashedVal() != null &&
        routing_node.getPred_PortHashedVal() != null &&
        routing_node.getSucc_PortHashedVal() != null){


    Log.i(TAG,"self and key"+ routing_node.getSelf_PortHashedVal().compareTo(key_Hash) );
    Log.i(TAG,"pred and key"+ routing_node.getPred_PortHashedVal().compareTo(key_Hash) );
    Log.i(TAG,"pred and curr" +routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()));
}
        if(routing_node.getPred_PortHashedVal() == null ||
                routing_node.getSelf_PortHashedVal() == null ||
                routing_node.getSelf_PortHashedVal() == null
                || routing_node.getPred_Port().equals(selfClientPort)
                || routing_node.getSucc_Port().equals(selfClientPort) ||

                (routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >= 0
                        && routing_node.getPred_PortHashedVal().compareTo(key_Hash) <=0)

        || ( routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
                && routing_node.getPred_PortHashedVal().compareTo(key_Hash) <=0 )

                || ( routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
                && routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >=0 )
        ){

            Log.i(TAG,"inside if");
          //write into file

            storeInCP(key_Hash,values.get("key").toString(),values.get("value").toString());



        }// end of routing node condition if
       else{ //if(key_Hash.compareTo(routing_node.getSelf_PortHashedVal()) > 0){

//values.get("key").toString()






            String  msgToSend ="" ;
            Socket socket = null;
            String remotePort ="";

            remotePort =  routing_node.getSucc_Port();

            Log.i("In Inserttt","remotePortNumb "+remotePort);



            try {

                socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(remotePort));


                Log.i("In Client", "connected to client with address " + socket.getRemoteSocketAddress() + " with port " + remotePort);

                 msgToSend =PASS_OR_INSERT + DELIMITER + values.get("key").toString()
                       + DELIMITER + key_Hash + DELIMITER +values.get("value").toString();
                Log.i("In Client", "message to Send " + msgToSend);
//                Log.i("In Insert", "connected to client with address " + insertSocket.getRemoteSocketAddress() + " with port " + remotePort);
//                Log.i("In Insert", "message to Send " + msgToSend);
//
                DataInputStream in = null;
                DataOutputStream out = null;




                //sending data to socket
                out = new DataOutputStream(socket.getOutputStream());
                out.writeUTF(msgToSend);
//                socket.setSoTimeout(2000);
                // receiving msg to close socket
                in = new DataInputStream(socket.getInputStream());



                String closeMsg = in.readUTF();
                Log.i("In Client", "closing socket At Client");


                if (closeMsg.equals(ACK)) {

                    socket.close();
                }


            }

            catch (Exception e)
            {

                Log.i("In Insert", "Inside try block catch"+ e.toString());
            }


        }// End of Hasvalue compare else if



        return null;
    }

    @Override
    public boolean onCreate() {
        // TODO Auto-generated method stub
        mUri = buildUri("content", "edu.buffalo.cse.cse486586.simpledht.provider");


        try{

      File dir = new File(getContext().getApplicationInfo().dataDir + "/files/");
            for(File file: dir.listFiles())
                if (!file.isDirectory())
                    file.delete();


        }catch (Exception e){
            Log.i(TAG,"Exception at file delete");
        }

    try {
        TelephonyManager tel = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);
        final String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
       //doubt
        selfClientPort = String.valueOf((Integer.parseInt(portStr) * 2));
      //  selfClientPort = portStr;
        selfPortHashedVal = genHash(selfClientPort);




    }
    catch (NoSuchAlgorithmException e){
        Log.i(TAG,"Exception in getting hashcode "+ e.toString());
    }

        try {
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            Log.i(TAG, "before socket function call");
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
        } catch (IOException e) {
            Log.i(TAG, "Can't create a ServerSocket");
           // return;
        }


       String  msgTosend =JOIN_REQ + DELIMITER + selfClientPort ;

//        InformAvd(msgTosend,MASTER_AVD);

        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msgTosend,selfClientPort);
        return false;


    }




    private class ClientTask extends AsyncTask<String, Void, Void> {


        @Override
        protected Void doInBackground(String... msgs) {

             String  msgToSend ="" ;
             Socket socket = null;
            String remotePort ="";

           // int AliveCount = 1;

            List<String> AliveArray = new ArrayList<String>();
            try {


                for( String port:REMOTE_PORT)
                {
                     remotePort = port;

                    //  Log.i("In Client","remotePortNumb "+remotePort);

                     socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(remotePort));

                     msgToSend = msgs[0];



                    // Added By SAI
                    msgToSend = CHECK_ALIVE + DELIMITER +remotePort;

                    Log.i("In Client", "connected to client with address " + socket.getRemoteSocketAddress() + " with port " + remotePort);
                    Log.i("In Client", "message to Send " + msgToSend);


                    DataInputStream in = null;
                    DataOutputStream out = null;



                    try {
                        //sending data to socket
                        out = new DataOutputStream(socket.getOutputStream());
                        out.writeUTF(msgToSend);

                        // receiving msg to close socket
                        in = new DataInputStream(socket.getInputStream());



                        String closeMsg = in.readUTF();
                        Log.i("In Client", "closing socket At Client");


                        if (closeMsg.equals(ACK)) {

                            AliveArray.add(remotePort);
                            socket.close();
                        }


                    }
                    catch (IOException e)
                    {

                        Log.i("In Client", "Inside try block catch");
                    }



                    //End Of SAI

                    // socket.close();
                }

            } catch (UnknownHostException e) {
                Log.i("In Client", "ClientTask UnknownHostException");
            } catch (IOException e) {
                Log.i("In Client", "ClientTask socket IOException");
            }





//Build chord
            try {


                    remotePort = msgs[1];

                    if(AliveArray.size() == 1 && !selfClientPort.equals(MASTER_AVD))
                    {



                        socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(selfClientPort));
                        msgToSend =SELF_JOIN_REQ + DELIMITER + selfClientPort;

                    }
//                    else if(selfClientPort.equals(MASTER_AVD))
//                    {
//
//                        socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(MASTER_AVD));
//                        msgToSend = BUILD_CHORD;
//
//
////                        for(int i=0; i < AliveArray.size(); i++)
//                        for(String str: AliveArray)
//                            msgToSend = msgToSend + DELIMITER + str;
//
//                    }
                    else
                    {


                        socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(MASTER_AVD));
                        msgToSend =JOIN_REQ + DELIMITER + selfClientPort;
                    }

                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());

             //   Log.i("In Client","Build Chord");

               // Log.i("In Client", "connected to client with address " + socket.getRemoteSocketAddress() + " with port " + remotePort);

//                Log.i("In client",msgToSend);
                    dos.writeUTF(msgToSend);

                DataInputStream dis = new DataInputStream(socket.getInputStream());
               String resMsg = dis.readUTF();




                    Log.i("In Client",resMsg);

                    if(resMsg != null && resMsg.equals(ACK))
                    {
                        socket.close();
                        Log.i("In Client","Response received from server");


                        } // resMsg if end


                }catch (SocketException e){
                    Log.i("In Client","Timeout when connecting to " + remotePort +  " " + e.toString());

                }
                catch (UnknownHostException e) {
                    Log.i("In Client", "ClientTask UnknownHostException when connecting to " + remotePort + " " + " " + e.toString());

                } catch (IOException e) {
                    Log.i("In Client", "ClientTask socket IOException "+ remotePort+  " "+ e.toString());

                }


            return null;
        }//do in background end
    }// ClientTask end




    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {


        @Override
        protected Void doInBackground(ServerSocket... sockets) {

            ServerSocket serverSocket = sockets[0];

            while (true) {

                Socket socket = null;


                try {
                    socket = serverSocket.accept();
                  //  BufferedReader read = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    DataInputStream in = null;
                 //   DataOutputStream out = null;
                    in = new DataInputStream(socket.getInputStream());
                String msg = in.readUTF();
                  //  String  msg = read.readLine();
//
//                    socket = serverSocket.accept();
//                    DataInputStream dis = new DataInputStream(socket.getInputStream());
//                    String msg = dis.readUTF();
                    Log.i(TAG, "Message from Client in the server is "+ msg);

                    if(msg != null){

                        String[] clientMsg = msg.split(DELIMITER);

                       if(clientMsg[0].equals(CHECK_ALIVE)){


                           DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                           dos.writeUTF(ACK);
                           dos.close();
                       }
                       else if(clientMsg[0].equals(SELF_JOIN_REQ)){

                           String joiningPort = clientMsg[1];
                           String hVal = genHash(Integer.toString(Integer.parseInt(joiningPort)/2));
                           Node joiningNode = new Node();
                           joiningNode.setSelf_ClientPort(joiningPort);
                           joiningNode.setSelf_PortHashedVal(hVal);

                           // Add to Chord
                           Chord.put(hVal,joiningNode);

                           String firstNode = Chord.keySet().toArray()[0].toString();
                           //String

                           //since only one chord the succ and pre are itself
                           // pass the hashedValue and update pred and succ
                           UpdatePredAndSucc(firstNode,firstNode,firstNode);

                        }//self join end else if
//                       else if(clientMsg[0].equals(BUILD_CHORD)){
//
//
//                           Chord.clear();
//
//                           for(int i=1; i < clientMsg.length; i++)
//                               AddtoChord(clientMsg[i]);
//
//                             //update node
//                            sendMessageToUpdateRoutingNode();
//
//                           DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
//                           dos.writeUTF(ACK);
//                           dos.close();
//                           printChordandRoutingNode();
//
//
//                       }
                        else if(clientMsg[0].equals(JOIN_REQ)){

                           //Add to chord
                            AddtoChord(clientMsg[1]);

                            //update node
                            sendMessageToUpdateRoutingNode();


                           printChordandRoutingNode();
                            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                            dos.writeUTF(ACK);
                            dos.close();

                        }//Join req if end
                        else if(clientMsg[0].equals(UPDATE_ROUTING_NODE)){

                            //msg order
                            // node nodeHashval |  predNode predHasval | sucNode sucHasval
                            updateRoutingNode(clientMsg[1], clientMsg[2], clientMsg[3], clientMsg[4], clientMsg[5], clientMsg[6]);



                           printChordandRoutingNode();
                            //ACK msg
                            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                            dos.writeUTF(ACK);
                            dos.close();

                        } // update routing node end
                        else if(clientMsg[0].equals(PASS_OR_INSERT)) {

                                //tag msg and msghashed

                            String key_Hash =clientMsg[2];

//                            Log.i(TAG,"Inside pass insert");
//
//                            Log.i(TAG,"key hashed" + key_Hash);
//                           Log.i(TAG,"pred HashedVal-> "+  routing_node.getPred_PortHashedVal());
//
//                           Log.i(TAG,"curr HashedVal-> "+  routing_node.getSelf_PortHashedVal());
//
//                           Log.i(TAG,"suc HashedVal -> "+  routing_node.getSucc_PortHashedVal());
////
////
//                           Log.e(TAG,"check pred and self crt order if negative ->  "+ routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()));
//                           Log.e(TAG,"check hash greater than pred if negative -> "+ routing_node.getPred_PortHashedVal().compareTo(key_Hash) );
//                           Log.e(TAG,"check hash smaller than cur if positive -> "+ routing_node.getSelf_PortHashedVal().compareTo(key_Hash) );
//

                           Log.i(TAG,"self and key"+ routing_node.getSelf_PortHashedVal().compareTo(key_Hash) );
                           Log.i(TAG,"pred and key"+ routing_node.getPred_PortHashedVal().compareTo(key_Hash) );
                           Log.i(TAG,"pred and curr" +routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()));




                           if(routing_node.getSelf_PortHashedVal() == null
                                   || routing_node.getPred_Port().equals(selfClientPort)
                                   || routing_node.getSucc_Port().equals(selfClientPort) ||

                                   (routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >= 0
                                           && routing_node.getPred_PortHashedVal().compareTo(key_Hash) <=0)

                                   || ( routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
                                   && routing_node.getPred_PortHashedVal().compareTo(key_Hash) <=0 )
                                   || ( routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
                                   && routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >=0 )
                           ){

                               Log.i(TAG,"insert into same  avd");
                                String ContentVal = clientMsg[3];
                                String ContentKey = clientMsg[1];
                               storeInCP(key_Hash,ContentKey,ContentVal);

                               DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                               dos.writeUTF(ACK);
                               dos.close();

                           } // store in CP if end
                           else {


                              try{

                                  String remotePort = routing_node.getSucc_Port();
                               Socket insertSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                           Integer.parseInt(remotePort));



                                  DataOutputStream dos = new DataOutputStream(insertSocket.getOutputStream());


                                  String msgToSend = msg;

                             Log.i("In Server", "connected to client with address " + insertSocket.getRemoteSocketAddress() + " with port " + remotePort);
                             Log.i("In server","PASSSS msg " + msgToSend);

                               dos.writeUTF(msgToSend);
                               DataInputStream dis = new DataInputStream(insertSocket.getInputStream());
                               String resMsg = dis.readUTF();


                               if(resMsg != null && resMsg.equals(ACK))
                               {
                                   insertSocket.close();
                                   Log.i("In Server","Response received after PASS Insert IN server");
                                    DataOutputStream tempdos = new DataOutputStream(socket.getOutputStream());
                                   tempdos.writeUTF(ACK);
                                   tempdos.close();
//                                       socket.close();
                               }
                              }
                              catch (Exception e){
                                  Log.i(TAG,"pass msg error"+e.toString());
                              }


                           } // else if ended for socket msg send
                       }//PASS OR INSERT else if end
                    else if(clientMsg[0].equals(GET_VALUE)){



                           String key_Hash =clientMsg[2];

                           if(routing_node.getSelf_PortHashedVal() == null
                                   || routing_node.getPred_Port().equals(selfClientPort)
                                   || routing_node.getSucc_Port().equals(selfClientPort) ||

                                   (routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >= 0
                                           && routing_node.getPred_PortHashedVal().compareTo(key_Hash) <=0)

                                   || ( routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
                                   && routing_node.getPred_PortHashedVal().compareTo(key_Hash) <=0 )
                                   || ( routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
                                   && routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >=0 )
                           ){

                               Log.i(TAG,"Query into same  avd");
                               //String ContentVal = clientMsg[3];
                               String ContentKey = clientMsg[1];
                              // storeInCP(key_Hash,ContentKey,ContentVal);
                               StringBuilder fileValue = getFileValue(ContentKey);

                               String resMsg = FILE_VALUE + DELIMITER +fileValue;
                               DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                               dos.writeUTF(resMsg);
                               dos.close();

                           } // end of if (same avd)
                        else{

                               try{

                                   String remotePort = routing_node.getSucc_Port();
                                   Socket insertSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                           Integer.parseInt(remotePort));



                                   DataOutputStream dos = new DataOutputStream(insertSocket.getOutputStream());


                                   String msgToSend = msg;



                                   Log.i("In Server", "connected to client with address " + insertSocket.getRemoteSocketAddress() + " with port " + remotePort);
                                   Log.i("In server","KEYY msg " + msgToSend);

                                   dos.writeUTF(msgToSend);
                                   DataInputStream dis = new DataInputStream(insertSocket.getInputStream());
                                   String resMsg = dis.readUTF();


                                   if(resMsg != null )
                                   {
                                       insertSocket.close();
                                       Log.i("In Server","Response received after PASS Insert IN server");
                                       DataOutputStream tempdos = new DataOutputStream(socket.getOutputStream());
                                       tempdos.writeUTF(resMsg);
                                       tempdos.close();
//                                       socket.close();
                                   }
                               }
                               catch (Exception e){
                                   Log.e(TAG,"Query msg error"+e.toString());
                               }





                           } // else this is for different avd insert


                       }//end of getValue else if
                     else if(clientMsg[0].equals(GET_ALL_VALUE)){

                           Log.i("inside all","query->"+ clientMsg[1]);
                           Log.i("inside all","succ port"+routing_node.getSucc_Port());

                           Cursor resultCursor = query(mUri, null,
                                   LOCAL_PAIRS_QUERY, null, null);




                         if(routing_node.getSucc_Port().equals(clientMsg[1])){
                             Log.i("inside all","if condition");


                        String avdMessages = cursorToString(resultCursor);

                             Log.i("inside all","if with avd"+avdMessages);

                             String resMsg = ALL_MESSAGES + DELIMITER +avdMessages;
                             Log.i("inside all","if with resMsg"+resMsg);


                             DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                             dos.writeUTF(resMsg);
                             dos.close();
                             Log.i("inside all","sent"+resMsg);

                         }// chord has been fully traversed
                         else
                         {
                             String avdMessages = cursorToString(resultCursor);
                             StringBuilder allAvdMsgBuilder = new StringBuilder();

                             if(avdMessages != null && avdMessages != ""){

                                 allAvdMsgBuilder.append(avdMessages);
                                 allAvdMsgBuilder.append(CV_DELIMETER);


                             }


                             try{

                                 String remotePort = routing_node.getSucc_Port();
                                 Socket querySocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                         Integer.parseInt(remotePort));



                                 DataOutputStream dos = new DataOutputStream(querySocket.getOutputStream());


                                 String msgToSend = msg;



                                 Log.i("In all query", "connected to client with address " + querySocket.getRemoteSocketAddress() + " with port " + remotePort);
                                 Log.i("In all query","all query msg " + msgToSend);

                                 dos.writeUTF(msgToSend);
                                 DataInputStream dis = new DataInputStream(querySocket.getInputStream());
                                 String resMsg = dis.readUTF();


                                 if(resMsg != null )
                                 {
                                     querySocket.close();
                                     String[] qAppend = resMsg.split(DELIMITER);

                                     Log.i("In server","Alll msg " + resMsg);


                                     if(qAppend.length > 1 && qAppend[0].equals(ALL_MESSAGES)){


                                        allAvdMsgBuilder.append(qAppend[1]);
                                    }



                                    String[] forMsgCount = allAvdMsgBuilder.toString().split(CV_DELIMETER);
                                     Log.i("In server"," "+ forMsgCount.length);

                                     String responseMsg = ALL_MESSAGES + DELIMITER +allAvdMsgBuilder;






                                     Log.i("In Server","Response received after PASS query IN server");
                                     Log.i("In server",responseMsg);
                                     DataOutputStream tempdos = new DataOutputStream(socket.getOutputStream());
                                     tempdos.writeUTF(responseMsg);
                                     tempdos.close();
//                                       socket.close();
                                 }
                             }
                             catch (Exception e){
                                 Log.e(TAG,"Query msg error"+e.toString());
                             }

                         } // else function for query all

                       } // end of getValue else if
                        else if(clientMsg[0].equals(DELETE_ALL_VALUE)){



                           Log.e("delete all","query->"+ clientMsg[1]);
                           Log.e("delete all","succ port"+routing_node.getSucc_Port());

                           delete(mUri,LOCAL_PAIRS_QUERY,null);


                           if(routing_node.getSucc_Port().equals(clientMsg[1])){

                               Log.e("delete all","if with resMsg");


                               DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                               dos.writeUTF(ACK);
                               dos.close();

                           }// chord has been fully traversed
                           else
                           {



                               try{

                                   String remotePort = routing_node.getSucc_Port();
                                   Socket deleteSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                           Integer.parseInt(remotePort));



                                   DataOutputStream dos = new DataOutputStream(deleteSocket.getOutputStream());


                                   String msgToSend = msg;



                                   Log.e("In all delete", "connected to client with address " + deleteSocket.getRemoteSocketAddress() + " with port " + remotePort);
                                   Log.e("In all delete","all query msg " + msgToSend);

                                   dos.writeUTF(msgToSend);
                                   DataInputStream dis = new DataInputStream(deleteSocket.getInputStream());
                                   String resMsg = dis.readUTF();


                                   if(resMsg != null )
                                   {
                                       deleteSocket.close();

                                      // String responseMsg = ALL_MESSAGES + DELIMITER +allAvdMsgBuilder;






                                       Log.i("In Server","Response received after PASS delete IN server");
                                     //  Log.i("In server",responseMsg);
                                       DataOutputStream tempdos = new DataOutputStream(socket.getOutputStream());
                                       tempdos.writeUTF(ACK);
                                       tempdos.close();
//                                       socket.close();
                                   }
                               }
                               catch (Exception e){
                                   Log.e(TAG,"Delete msg error"+e.toString());
                               }

                           } // else function for delete all



                       } //end of DELETE_ALL_VALUE
                       else if(clientMsg[0].equals(PASS_OR_DELETE)) {

                           //tag msg and msghashed

                           String key_Hash =clientMsg[2];

//
                           Log.e(TAG,"self and key"+ routing_node.getSelf_PortHashedVal().compareTo(key_Hash) );
                           Log.e(TAG,"pred and key"+ routing_node.getPred_PortHashedVal().compareTo(key_Hash) );
                           Log.e(TAG,"pred and curr" +routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()));




                           if(routing_node.getSelf_PortHashedVal() == null
                                   || routing_node.getPred_Port().equals(selfClientPort)
                                   || routing_node.getSucc_Port().equals(selfClientPort) ||

                                   (routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >= 0
                                           && routing_node.getPred_PortHashedVal().compareTo(key_Hash) <=0)

                                   || ( routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
                                   && routing_node.getPred_PortHashedVal().compareTo(key_Hash) <=0 )
                                   || ( routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
                                   && routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >=0 )
                           ){

                               Log.e(TAG,"delete into same  avd");
                              // String ContentVal = clientMsg[3];
                               String ContentKey = clientMsg[1];
                              deleteFromCP(ContentKey);

                               DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                               dos.writeUTF(ACK);
                               dos.close();

                           } // delete in CP if end
                           else {


                               try{

                                   String remotePort = routing_node.getSucc_Port();
                                   Socket deleteSocket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                                           Integer.parseInt(remotePort));



                                   DataOutputStream dos = new DataOutputStream(deleteSocket.getOutputStream());


                                   String msgToSend = msg;

                                   Log.i("In Server", "connected to client with address " + deleteSocket.getRemoteSocketAddress() + " with port " + remotePort);
                                   Log.i("In server","PASSSS for delete msg " + msgToSend);

                                   dos.writeUTF(msgToSend);
                                   DataInputStream dis = new DataInputStream(deleteSocket.getInputStream());
                                   String resMsg = dis.readUTF();


                                   if(resMsg != null && resMsg.equals(ACK))
                                   {
                                       deleteSocket.close();
                                       Log.i("In Server","Response received after PASS Insert IN server");
                                       DataOutputStream tempdos = new DataOutputStream(socket.getOutputStream());
                                       tempdos.writeUTF(ACK);
                                       tempdos.close();
//                                       socket.close();
                                   }
                               }
                               catch (Exception e){
                                   Log.i(TAG,"pass msg error"+e.toString());
                               }


                           } // else if ended for socket msg send
                       }//PASS OR DELETE else if end


                    } // msg not null if condition end


                }
                catch(Exception e){
                    Log.i(TAG, "Exception occured in ServerTask"+ e.toString());

                }

            }





          //  return null;
        }

        protected void onProgressUpdate(String... strings) {


            return;
        }
    } // server task end

//my functions

    public void deleteFromCP(String contentKey){

        File Files = new File(getContext().getApplicationInfo().dataDir+"/files/"+contentKey);

        if(Files.delete()){
            Log.e("File","deleted successfully");
        }
        else
        {

            Log.e("File"," not deleted");
        }


    }

    public String cursorToString(Cursor resultCursor){




        Cursor result = resultCursor;

        StringBuilder sb = new StringBuilder();

        int keyIndex = resultCursor.getColumnIndex(KEY_FIELD);
        int valueIndex = resultCursor.getColumnIndex(VALUE_FIELD);
        if (resultCursor != null) {
            // move cursor to first row
            if (resultCursor.moveToFirst()) {
                do {


                    String returnKey = resultCursor.getString(0);
                    String returnValue = resultCursor.getString(1);

                    sb.append(returnKey);
                    sb.append(CV_DELIMETER);
                    sb.append(returnValue);
                    sb.append(CV_DELIMETER);

                    // Log.e(TAG,"key -> " + returnKey);

//                    Log.e(TAG,"val -> " + returnValue);

                } while (resultCursor.moveToNext());
            }
        } //resultCursor not null check
        if(sb.length() > 0){
            sb.deleteCharAt(sb.length() - 1);
        }

        return sb.toString();
    }

public void storeInCP(String key_Hash,String contentKey, String contentVal){


    //write into file
    File Files = new File(getContext().getApplicationInfo().dataDir+"/files/"+contentKey);

    //delete file before write
    if(Files.delete())
    {
        Log.v("Provider","delete of file successfull "+ contentKey);
    }


    try{
        FileOutputStream outputStream;
        outputStream = getContext().openFileOutput(contentKey, Context.MODE_PRIVATE);
        outputStream.write(contentVal.getBytes());
        outputStream.close();

    }
    catch (IOException e)
    {
        Log.i("Exception","file write failed"+e.toString());
    }
}



public void printChordandRoutingNode(){
    Log.i("In Clint", "Chord");
    for (Map.Entry<String, Node>
            entry : Chord.entrySet()){

        Integer avd =(Integer.parseInt(entry.getValue().getSelf_ClientPort()) - 11108) / 4;
        Integer Pre_avd =(Integer.parseInt(entry.getValue().getPred_Port()) - 11108) / 4;
        Integer Succ_avd =(Integer.parseInt(entry.getValue().getSucc_Port()) - 11108) / 4;

     //   Log.i("HashedVal ", "Node-> "+entry.getValue().getSelf_PortHashedVal());
//
//        Log.i("Values ", "Pred-> "+Pre_avd);
//        Log.i("Values ", "Node-> "+avd);
//        Log.i("HVal"," "+ entry.getValue().getSelf_PortHashedVal());
//        Log.i("Values ", "Succc-> "+Succ_avd);

    }


}


public void updateRoutingNode(String selfPort, String selfHashedVal, String PrePort, String PreHashedVal, String SucPort, String SucHashedVal){

     //self
    routing_node.setSelf_ClientPort(selfPort);
    routing_node.setSelf_PortHashedVal(selfHashedVal);

    //pred
    routing_node.setPred_Port(PrePort);
    routing_node.setPred_PortHashedVal(PreHashedVal);

    //succ
    routing_node.setSucc_Port(SucPort);
    routing_node.setSucc_PortHashedVal(SucHashedVal);


}

public void sendMessageToUpdateRoutingNode(){




    for (Map.Entry<String, Node>
            entry : Chord.entrySet()){

        //if it is master update directly
        if(entry.getValue().getSelf_ClientPort().equals(MASTER_AVD) ){


            // node nodeHashval |  predNode predHasval | sucNode sucHasval
            updateRoutingNode(MASTER_AVD, entry.getValue().getSelf_PortHashedVal(),
                    entry.getValue().getPred_Port(), entry.getValue().getPred_PortHashedVal(),
                    entry.getValue().getSucc_Port(),
                    entry.getValue().getSucc_PortHashedVal());



         continue;
         }

        if(entry.getValue().getSelf_ClientPort().equals(selfClientPort)){


            // node nodeHashval |  predNode predHasval | sucNode sucHasval
            updateRoutingNode(selfClientPort, entry.getValue().getSelf_PortHashedVal(),
                    entry.getValue().getPred_Port(), entry.getValue().getPred_PortHashedVal(),
                    entry.getValue().getSucc_Port(),
                    entry.getValue().getSucc_PortHashedVal());


            continue;
        }








    //if not send msg to update the routing node
    try{

        Socket socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}), Integer.parseInt(entry.getValue().getSelf_ClientPort()));
        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());


        String msgToSend ;

        // node nodeHashval   predNode predHasval sucNode sucHasval
        msgToSend = UPDATE_ROUTING_NODE + DELIMITER + entry.getValue().getSelf_ClientPort() + DELIMITER + entry.getValue().getSelf_PortHashedVal() + DELIMITER +
        entry.getValue().getPred_Port() + DELIMITER + entry.getValue().getPred_PortHashedVal() + DELIMITER +
        entry.getValue().getSucc_Port() + DELIMITER + entry.getValue().getSucc_PortHashedVal();



        Log.i("In server","sendMessageToUpdateRoutingNode msg " + msgToSend);

        dos.writeUTF(msgToSend);
        DataInputStream dis = new DataInputStream(socket.getInputStream());
        String resMsg = dis.readUTF();


        if(resMsg != null && resMsg.equals(ACK))
        {
            socket.close();
            Log.i("In Server","Response received after sendMessageToUpdateRoutingNode from server");

        }




    } catch(Exception e){
        Log.i(TAG, "Exception occured in sendMessageToUpdateRoutingNode"+ e.toString());

    }
//







    }// end of for loop




}

public void UpdatePredAndSucc(String node,String pred,String succ){



    if(pred != ""){


    Chord.get(node).setPred_Port(Chord.get(pred).getSelf_ClientPort());
    Chord.get(node).setPred_PortHashedVal(Chord.get(pred).getSelf_PortHashedVal());
    }

    if(succ != ""){
        Chord.get(node).setSucc_Port(Chord.get(succ).getSelf_ClientPort());
        Chord.get(node).setSucc_PortHashedVal(Chord.get(succ).getSelf_PortHashedVal());
    }



}


public void  AddtoChord(String joiningPort){





    if(Chord.isEmpty()){
        try{


            String hVal = genHash(Integer.toString(Integer.parseInt(joiningPort)/2));
            Node joiningNode = new Node();
            joiningNode.setSelf_ClientPort(joiningPort);
            joiningNode.setSelf_PortHashedVal(hVal);

            // Add to Chord
            Chord.put(hVal,joiningNode);

            String firstNode = Chord.keySet().toArray()[0].toString();
            //String

            //since only one chord the succ and pre are itself
            // pass the hashedValue and update pred and succ
            UpdatePredAndSucc(firstNode,firstNode,firstNode);







            }
        catch (NoSuchAlgorithmException e){
           Log.i("In Server", "Chord empty catch block "+ e.toString());
        }

    } //Chord empty if end
    else if(Chord.size() == 1){
        try{
            String hVal = genHash(Integer.toString(Integer.parseInt(joiningPort)/2));
            Node joiningNode = new Node();
            joiningNode.setSelf_ClientPort(joiningPort);
            joiningNode.setSelf_PortHashedVal(hVal);

            Chord.put(hVal,joiningNode);

            String firstNode = Chord.keySet().toArray()[0].toString();
            String SecondNode = Chord.keySet().toArray()[1].toString();

            //When u have two node pred and succ and each other
            UpdatePredAndSucc(firstNode,SecondNode,SecondNode);
            UpdatePredAndSucc(SecondNode,firstNode,firstNode);


        }
        catch (NoSuchAlgorithmException e){
            Log.i("In Server", "Chord size 1 "+ e.toString());
        }


    } // end of else if of size 1
    else{
        try{
            String hVal = genHash(Integer.toString(Integer.parseInt(joiningPort)/2));
            Node joiningNode = new Node();
            joiningNode.setSelf_ClientPort(joiningPort);
            joiningNode.setSelf_PortHashedVal(hVal);

            Chord.put(hVal,joiningNode);
            String firstNode = Chord.keySet().toArray()[0].toString();
            String secondNode = Chord.keySet().toArray()[1].toString();
            String penultimate =Chord.keySet().toArray()[Chord.size()-2].toString();
            String lastNode = Chord.keySet().toArray()[Chord.size()-1].toString();

            UpdatePredAndSucc(firstNode,lastNode,secondNode);
            UpdatePredAndSucc(lastNode,penultimate,firstNode);

            for(int i=1; i < Chord.size()-1; i++){

                String Prev = Chord.keySet().toArray()[i-1].toString();
                String NodeToUpdate = Chord.keySet().toArray()[i].toString();
                String Nxt = Chord.keySet().toArray()[i+1].toString();

                //Update Chord
                UpdatePredAndSucc(NodeToUpdate,Prev,Nxt);



            }



        }
        catch (NoSuchAlgorithmException e){
            Log.i("In Server", "Chord size greater than 2 "+ e.toString());
        }
    } // end of else chord


}public StringBuilder getFileValue(String selection){

        Log.v("query", selection);
        Log.v("Directory",getContext().getApplicationInfo().dataDir);


        File f = new File(getContext().getApplicationInfo().dataDir+"/files");


        File[] list= f.listFiles();

        StringBuilder sb = new StringBuilder();
        for(File fil:list)
        {
            if(fil.getName().equals(selection))
            {
                Log.i("SearchFile","found file "+selection);

                try{


                    FileInputStream fis = getContext().openFileInput(selection);
                    InputStreamReader isr = new InputStreamReader(fis);
                    BufferedReader bufferedReader = new BufferedReader(isr);

                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        sb.append(line);
                    }

                    Log.i("value in file", String.valueOf(sb));


                   // cursor.newRow().add("key",selection).add("value",sb);
                    return sb;

                }
                catch (FileNotFoundException e)
                {
                    Log.e("Exception","file read failed"+e.toString());
                }
                catch (IOException e)
                {
                    Log.e("Exception","IOEXception"+ e.toString());
                }

                break;
            }

        }

return sb;


    }


//end of my function

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
            String sortOrder) {
        // TODO Auto-generated method stub



        MatrixCursor cursor = new MatrixCursor(
                new String[] {"key", "value"}
        );
        if (routing_node.getSucc_PortHashedVal() == null
               || routing_node.getPred_PortHashedVal() == null
        || routing_node.getSelf_PortHashedVal() == null
              || selection.contains(LOCAL_PAIRS_QUERY)){

            File f = new File(getContext().getApplicationInfo().dataDir+"/files");

            if( !f.isDirectory()) // if dir is not present
                return cursor;

            File[] list= f.listFiles();

            //empty dir
            if(list.length < 1)
                return cursor;

            for(File fil:list)
            {

                String fileName = fil.getName();
                    Log.i("SearchFile","found file "+fileName);

                    try{


                        FileInputStream fis = getContext().openFileInput(fileName);
                        InputStreamReader isr = new InputStreamReader(fis);
                        BufferedReader bufferedReader = new BufferedReader(isr);
                        StringBuilder sb = new StringBuilder();
                        String line;
                        while ((line = bufferedReader.readLine()) != null) {
                            sb.append(line);
                        }

                    //    Log.i("value in file", String.valueOf(sb));



                        cursor.newRow().add("key",fileName).add("value",sb);


                    }
                    catch (FileNotFoundException e)
                    {
                        Log.i("Exception","file read failed"+e.toString());
                    }
                    catch (IOException e)
                    {
                        Log.i("Exception","IOEXception"+ e.toString());
                    }


            } // end of file traversal for
            return cursor;

        } //end of routing selfnode if
        else if(selection.contains(ALL_PAIRS_QUERY)){



            Log.e(TAG, "call @ from *");

            Cursor resultCursor = this.query(mUri, null,
                    LOCAL_PAIRS_QUERY, null, null);



            Cursor result = resultCursor;
         //   int keyIndex = resultCursor.getColumnIndex(KEY_FIELD);
          //  int valueIndex = resultCursor.getColumnIndex(VALUE_FIELD);
            if (resultCursor != null) {
                // move cursor to first row
                if (resultCursor.moveToFirst()) {
                    do {


                        String returnKey = resultCursor.getString(0);
                        String returnValue = resultCursor.getString(1);

                  //      Log.e(TAG,"key -> " + returnKey);

                    //    Log.e(TAG,"val -> " + returnValue);

                        //indexCount++;
                        // move to next row
                    } while (resultCursor.moveToNext());
                }
            } //resultCursor not null check

            if(routing_node.getSucc_PortHashedVal() == null
                    || routing_node.getPred_PortHashedVal() == null
                    || routing_node.getSelf_PortHashedVal() == null
                    ||  routing_node.getSelf_ClientPort().equals(routing_node.getPred_Port())
                    ||  routing_node.getSelf_ClientPort().equals(routing_node.getSucc_Port())

            ){

              return result;
            } // if only one AVD




         //create a socket and req for all pair query
            String  msgToSend  ;
            Socket socket ;
            String remotePort ;

            remotePort =  routing_node.getSucc_Port();

            Log.e("In Query"," for * remotePortNumb "+remotePort);



            try {

                socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                        Integer.parseInt(remotePort));


                Log.e("In Query", "connected to client with address " + socket.getRemoteSocketAddress() + " with port " + remotePort);

                msgToSend =GET_ALL_VALUE + DELIMITER + routing_node.getSelf_ClientPort();

                Log.e("In Query", "message to Send " + msgToSend);
//                Log.i("In Insert", "connected to client with address " + insertSocket.getRemoteSocketAddress() + " with port " + remotePort);
                Log.i("In Query", "message to Send " + msgToSend);
//
                DataInputStream in = null;
                DataOutputStream out = null;




                //sending data to socket
                out = new DataOutputStream(socket.getOutputStream());
                out.writeUTF(msgToSend);
//                socket.setSoTimeout(2000);
                // receiving msg to close socket
                in = new DataInputStream(socket.getInputStream());



                String closeMsg = in.readUTF();
                Log.e("In Query", "closing socket at query"+ closeMsg);


                if (closeMsg != null) {
                   // String[] clientMsg = closeMsg.split(DELIMITER);

//                    cursor.newRow().add("key",selection).add("value",clientMsg[1]);

                    Log.e(TAG,"ACK received for * ");

                    Log.e(TAG,closeMsg);

                     String[] allMsg = closeMsg.split(DELIMITER);


                    Log.e(TAG,"allMsg length"+allMsg.length);
                     String [] keyvalMsg =  allMsg[1].split(CV_DELIMETER);

                    Log.e(TAG,"length"+keyvalMsg.length);
                    for(int i=0; i < keyvalMsg.length -1; i+=2){

                        cursor.newRow().add("key",keyvalMsg[i]).add("value",keyvalMsg[i+1]);


                    }

                    MergeCursor mergeCursor = new MergeCursor(new Cursor[] { cursor, result });


                    socket.close();
                    return mergeCursor;
                }


            }

            catch (Exception e)
            {

                Log.e("In Query", "Inside try block catch"+ e.toString());
            }


            return result;






        }// star query else if end
        else {//if(!selection.contains("*")){

            String key = selection;
            String key_Hash="";

            try{
                key_Hash=genHash(selection);
                Log.i("Key hash: ",key_Hash);
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }


            if(routing_node.getSelf_PortHashedVal() == null
                    || routing_node.getPred_Port().equals(selfClientPort)
                    || routing_node.getSucc_Port().equals(selfClientPort) ||

                    (routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >= 0
                            && routing_node.getPred_PortHashedVal().compareTo(key_Hash) <=0)

                    || ( routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
                    && routing_node.getPred_PortHashedVal().compareTo(key_Hash) <=0 )
                    || ( routing_node.getPred_PortHashedVal().compareTo(routing_node.getSelf_PortHashedVal()) >= 0
                    && routing_node.getSelf_PortHashedVal().compareTo(key_Hash) >=0 )
            ) {



                StringBuilder fileValue;


                fileValue = getFileValue(selection);

                cursor.newRow().add("key",selection).add("value",fileValue);
                return cursor;


            }//end of if inside particular key
            else {

                 String  msgToSend  ;
                Socket socket ;
                String remotePort ;

                remotePort =  routing_node.getSucc_Port();

                Log.e("In Query","remotePortNumb "+remotePort);



                try {

                    socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(remotePort));


                    Log.e("In Query", "connected to client with address " + socket.getRemoteSocketAddress() + " with port " + remotePort);

                    msgToSend =GET_VALUE + DELIMITER + key
                            + DELIMITER + key_Hash;
                    Log.e("In Query", "message to Send " + msgToSend);
//                Log.i("In Insert", "connected to client with address " + insertSocket.getRemoteSocketAddress() + " with port " + remotePort);
                Log.i("In Query", "message to Send " + msgToSend);
//
                    DataInputStream in = null;
                    DataOutputStream out = null;




                    //sending data to socket
                    out = new DataOutputStream(socket.getOutputStream());
                    out.writeUTF(msgToSend);
//                socket.setSoTimeout(2000);
                    // receiving msg to close socket
                    in = new DataInputStream(socket.getInputStream());



                    String closeMsg = in.readUTF();
                    Log.e("In Query", "closing socket at query"+ closeMsg);


                    if (closeMsg != null) {
                        String[] clientMsg = closeMsg.split(DELIMITER);

                        cursor.newRow().add("key",selection).add("value",clientMsg[1]);


                        socket.close();
                        return cursor;
                    }


                }

                catch (Exception e)
                {

                    Log.e("In Query", "Inside try block catch"+ e.toString());
                }


               // return cursor;

            }//end of else





        } //end of else if Query particular key ( not star)








        return null;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // TODO Auto-generated method stub
        return 0;
    }

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }
}
