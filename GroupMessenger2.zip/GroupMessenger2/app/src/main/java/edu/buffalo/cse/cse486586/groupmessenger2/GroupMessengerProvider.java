package edu.buffalo.cse.cse486586.groupmessenger2;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * GroupMessengerProvider is a key-value table. Once again, please note that we do not implement
 * full support for SQL as a usual ContentProvider does. We re-purpose ContentProvider's interface
 * to use it as a key-value table.
 * 
 * Please read:
 * 
 * http://developer.android.com/guide/topics/providers/content-providers.html
 * http://developer.android.com/reference/android/content/ContentProvider.html
 * 
 * before you start to get yourself familiarized with ContentProvider.
 * 
 * There are two methods you need to implement---insert() and query(). Others are optional and
 * will not be tested.
 * 
 * @author stevko
 *
 */
public class GroupMessengerProvider extends ContentProvider {

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // You do not need to implement this.
        return 0;
    }

    @Override
    public String getType(Uri uri) {
        // You do not need to implement this.
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {

        Log.v("insert", values.toString());


        String val = values.get("value").toString();
        Log.v("getval", val);
        String key = values.get("key").toString();
        Log.v("getkey", key);

        File Files = new File(getContext().getApplicationInfo().dataDir+"/files/"+key);

        //delete file before write
        if(Files.delete())
        {
            Log.v("Provider","delete of file successfull "+ key);
        }


        try{
            FileOutputStream outputStream;
            outputStream = getContext().openFileOutput(key, Context.MODE_PRIVATE);
            outputStream.write(val.getBytes());
            outputStream.close();

        }
        catch (IOException e)
        {
            Log.e("Exception","file write failed"+e.toString());
        }



        return uri;
    }

    @Override
    public boolean onCreate() {
        // If you need to perform any one-time initialization task, please do it here.
        return false;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        // You do not need to implement this.
        return 0;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
                        String sortOrder) {
        Log.v("query", selection);



        Log.v("Directory",getContext().getApplicationInfo().dataDir);


        File f = new File(getContext().getApplicationInfo().dataDir+"/files");


        File[] list= f.listFiles();


        for(File fil:list)
        {
            if(fil.getName().equals(selection))
            {
                Log.i("SearchFile","found file "+selection);

                try{


                    FileInputStream fis = getContext().openFileInput(selection);
                    InputStreamReader isr = new InputStreamReader(fis);
                    BufferedReader bufferedReader = new BufferedReader(isr);
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        sb.append(line);
                    }

                    Log.i("value in file", String.valueOf(sb));


                    MatrixCursor cursor = new MatrixCursor(
                            new String[] {"key", "value"}
                    );

                    cursor.newRow().add("key",selection).add("value",sb);
                    return cursor;

                }
                catch (FileNotFoundException e)
                {
                    Log.e("Exception","file read failed"+e.toString());
                }
                catch (IOException e)
                {
                    Log.e("Exception","IOEXception"+ e.toString());
                }

                break;
            }

        }



        return null;
    }
}
