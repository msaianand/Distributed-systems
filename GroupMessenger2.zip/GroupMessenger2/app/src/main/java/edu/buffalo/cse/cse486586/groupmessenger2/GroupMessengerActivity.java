package edu.buffalo.cse.cse486586.groupmessenger2;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.sql.SQLSyntaxErrorException;
import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

/**
 * GroupMessengerActivity is the main Activity for the assignment.
 *
 * @author stevko
 */
public class GroupMessengerActivity extends Activity {


    static final String TAG = GroupMessengerActivity.class.getSimpleName();
    //static final String REMOTE_PORT0 = "11108";
    //static final String REMOTE_PORT1 = "11112";
    //static final String REMOTE_PORT[] = {"11108", "11112"};//{"11108","11112","11116","11120","11124"};
    // static final String REMOTE_PORT[]= {"11108","11112","11116"};//{"11108","11112","11116","11120","11124"};

     static final String REMOTE_PORT[]= {"11108","11112","11116","11120","11124"};

    static final int SERVER_PORT = 10000;
    static final String URL = "content://edu.buffalo.cse.cse486586.groupmessenger2.provider";
    static final Uri CONTENT_URI = Uri.parse(URL);
    static int SEQ_NO = -1;

    static int msgID = 0;
    static int proposed_SeqNumb = 0;
    private static final String PROPOSAL_REQUEST = "Request_Proposal";
    private static final String PROPOSAL_RESPONSE = "Send_Proposal";
    private static final String AGREED_SEQ = "Max_Seq";
    private static final String KEY_FIELD = "key";
    private static final String VALUE_FIELD = "value";
    private static final String DELIMITER = ":";
    //float f = (float) 0.0;
    float[] maxagreedSeqNumb = new float[1000];// =  { f };
    private Integer selfClientPort;
    private Integer selfPId;
    TreeMap<Float, MessageObject> holdBack = new TreeMap<Float, MessageObject>();
    //End Of SAI
    ArrayList<MessageObject> CheckOrder = new ArrayList<MessageObject>(100);

    class MessageObject {
        int messageId;
        String remotePort;
        float suggestedSeqNumb;
        float agreedSeqNumb;
        boolean isDeliverable;
        String message;


        MessageObject(String remotePort, int messageId, float suggestedSeqNumb, float agreedSeqNum, boolean isDeliverable, String message) {

            this.remotePort = remotePort;
            this.messageId = messageId;
            this.suggestedSeqNumb = suggestedSeqNumb;
            this.agreedSeqNumb = agreedSeqNum;
            this.isDeliverable = isDeliverable;
            this.message = message;
        }


        @Override
        public String toString() {
            return "this is message is from " + remotePort + " with id " + messageId + " of sug seq " + suggestedSeqNumb + " of agree seq " + agreedSeqNumb + " with status " + isDeliverable + " and " + message;
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_messenger);

        /*
         * TODO: Use the TextView to display your messages. Though there is no grading component
         * on how you display the messages, if you implement it, it'll make your debugging easier.
         */
        TextView tv = (TextView) findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());

        /*
         * Registers OnPTestClickListener for "button1" in the layout, which is the "PTest" button.
         * OnPTestClickListener demonstrates how to access a ContentProvider.
         */
        findViewById(R.id.button1).setOnClickListener(
                new OnPTestClickListener(tv, getContentResolver()));
        //Added By SAI
        Log.i(TAG, "Before socket creation");

        //Added By SAI
        TelephonyManager tel = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);
        final String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        selfClientPort = (Integer.parseInt(portStr) * 2);
        selfPId = (selfClientPort - 11108) / 4;

        try {

            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            Log.i(TAG, "before socket function call");
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
        } catch (IOException e) {
            Log.i(TAG, "Can't create a ServerSocket");
            return;
        }


        //End Of Sai
        final EditText editText = (EditText) findViewById(R.id.editText1);


        Button mButton = (Button) findViewById(R.id.button4);
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Do something
                Log.i("onlick", "onclick");
                Log.i(TAG, "Enter key pressed");
                String msg = editText.getText().toString() + "\n";
                editText.setText("");

                msgID++;

                String msgTosend = PROPOSAL_REQUEST + DELIMITER + selfClientPort.toString() + DELIMITER + msgID + DELIMITER + msg;
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, msgTosend);

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_group_messenger, menu);
        return true;
    }


    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {


        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];


            //Added By SAI


            while (true) {
                Socket socket = null;


                try {
                    socket = serverSocket.accept();
                    DataInputStream dis = new DataInputStream(socket.getInputStream());
                    String msg = dis.readUTF();

                    String[] chatArray = msg.split(DELIMITER);

                    if(chatArray[0].equals(PROPOSAL_REQUEST)){
//                        publishProgress(msg);

                        synchronized (this)
                        {
                            proposed_SeqNumb++;
                        }


                        String sugSeq = proposed_SeqNumb +"." + selfPId ;


                        MessageObject msgObj = new MessageObject(chatArray[1], Integer.valueOf(chatArray[2]), Float.valueOf(sugSeq), Float.valueOf(0), false, chatArray[3]);
                        holdBack.put(Float.valueOf(sugSeq) , msgObj);

                        Log.i("In Server Request", msgObj.toString());

                        String msgTosendFromServer = PROPOSAL_RESPONSE + DELIMITER + chatArray[1] + DELIMITER + chatArray[2] + DELIMITER + chatArray[3] + DELIMITER + sugSeq;
                        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                        dos.writeUTF(msgTosendFromServer);
                        dos.close();
                    } else{
//                        System.out.println("Came for 2nd For loop");
                        String agreedNumber = chatArray[4].trim();

                        float f = Float.parseFloat(agreedNumber);
                       /// Log.e("Inserver","floatvalue"+ f);
                        //Log.i("Inserver","aff"+ agreedNumber.charAt(0));
//                        int intAgr = (int)f;
//                        Log.i("Inserver","leng "+ intAgr);


                        for (Map.Entry<Float, MessageObject>
                                entry : holdBack.entrySet()) {

                            //Log.i("Server","inside fore");
                            Log.i("In Server", "remote Port " + chatArray[1]);

                            Log.i("In Server", "msg ID " + chatArray[2]);

                            Log.i("In Server", "msgg " + chatArray[3]);

                            Log.i("In Server", "maxseq " + chatArray[4]);
                            if (entry.getValue().remotePort.equals(chatArray[1]) && entry.getValue().messageId == Integer.parseInt(chatArray[2])) {

                                Float sugSeq = entry.getValue().suggestedSeqNumb;
                                holdBack.remove(entry.getKey());
                                float max = Float.valueOf(chatArray[4]);
                                if(proposed_SeqNumb < max)
                                    proposed_SeqNumb = (int)max +1;

                                MessageObject msgObj = new MessageObject(chatArray[1], Integer.valueOf(chatArray[2]), sugSeq, Float.valueOf(chatArray[4]), true, chatArray[3]);
                                holdBack.put(Float.valueOf(chatArray[4]), msgObj);

                                Log.i("In Server AgreedSeq", msgObj.toString());
                                break;


                            }
                        }


                        DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                        dos.writeUTF("over");
                        dos.close();

                        for (Map.Entry<Float, MessageObject>
                                entry : holdBack.entrySet())
                            Log.i("In Server","[[[" + entry.getKey()+ ", " + entry.getValue().toString() + "]");


                        synchronized (holdBack) {


                        while(!holdBack.isEmpty()) {

                            Log.i("In Server",holdBack.firstEntry().getValue().toString());

                            if(!holdBack.isEmpty() && holdBack.firstEntry().getValue().isDeliverable == true)
                            {

                                CheckOrder.add(holdBack.firstEntry().getValue());

                               // String display = holdBack.firstEntry().getValue().toString();
                                MessageObject mo = holdBack.firstEntry().getValue();
                                publishProgress(mo.message);
                                holdBack.pollFirstEntry();

                            }
                            else
                            {
                                break;
                            }
                        }
                        }


                    Log.i("In Server","Printing the op Queue[[[[[[");

                        //for(int i =0; i < CheckOrder.size(); i++)
                        //{


                        //}
                        for (MessageObject each : CheckOrder) {
                            //Log.i("In Server",CheckOrder[i].)

                            Log.e("In Server", each.toString());
                        }

                    }
//                    dis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

//

            }
        }

        protected void onProgressUpdate(String... strings) {

            String strReceived = strings[0].trim();
            TextView remoteTextView = (TextView) findViewById(R.id.textView1);
            remoteTextView.append(strReceived + "\t\n");


            try {


                Log.i(TAG, "onProgressUpdate");
                String string = strReceived + "\n";


                SEQ_NO++;
                ContentValues values = new ContentValues();

                values.put(KEY_FIELD, Integer.toString(SEQ_NO));
                values.put(VALUE_FIELD, string);

                String val = values.get("value").toString();
                Log.v("getval in server", val);
                String key = values.get("key").toString();
                Log.v("getkey in server", key);


                //mContentResolver.insert(mUri, mContentValues[i]);

                getContentResolver().insert(CONTENT_URI, values);
                Log.i("Server", " New message has  been added and SeqNumb" + SEQ_NO);
            } catch (NullPointerException e) {
                Log.e("Exception", "inside server background" + e.toString());

            }
            return;
        }
    }

    private class ClientTask extends AsyncTask<String, Void, Void> {


        @Override
        protected Void doInBackground(String... msgs) {


            String msgToSend = msgs[0];

            for(String each : REMOTE_PORT){
                Socket socket = null;
                try {
                    socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(each));
                    DataOutputStream dos = new DataOutputStream(socket.getOutputStream());

                    Log.i("In Server",msgToSend);

                    //dos.writeUTF("Hello");
                    dos.writeUTF(msgToSend);
                    DataInputStream dis = new DataInputStream(socket.getInputStream());
                    String resMsg = dis.readUTF();

                    //String[] msgArray = msg.split(DELIMITER);
                    //Log.i("In Client",msg);

                    Log.i("In Client",resMsg);
                    String[] resArray = resMsg.split(DELIMITER);

                    if(resArray[0].equals(PROPOSAL_RESPONSE))
                    {
                        maxagreedSeqNumb[msgID] = Math.max(maxagreedSeqNumb[msgID], Float.valueOf(resArray[4]));
                        Log.i("In Client","for each seq "+maxagreedSeqNumb[msgID] );
                    }

                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            //Frame Agreed Seq

            String[] splitArray = msgs[0].split(DELIMITER);

            // Log.i("in CLient","splitArraylength"+splitArray.length);

            String msgToSendSecondTime = AGREED_SEQ + DELIMITER + selfClientPort + DELIMITER + msgID + DELIMITER + splitArray[3].trim() + DELIMITER +  maxagreedSeqNumb[msgID];


            for(String each : REMOTE_PORT){
                Socket socket = null;
                try {
                    socket = new Socket(InetAddress.getByAddress(new byte[]{10, 0, 2, 2}),
                            Integer.parseInt(each));
                    DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                    //dos.writeUTF("World");
                    dos.writeUTF(msgToSendSecondTime);

                    DataInputStream dis = new DataInputStream(socket.getInputStream());
                    String msg = dis.readUTF();
                    if(msg.equals("over")){
                        System.out.println("Closing Socket ------>");
                        socket.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }
    }


}
